# K7-B 24-pair filtered-donor gallery

This is the completed 24-pair K7-B, 8-shot review using the rerun that excludes highly similar font-name prefixes before donor retrieval.

The viewer shows the target glyph, ground truth, original K7-B prediction, filtered-run prediction, the ten retained donor fonts with each donor's target glyph and eight reference images, and the target font's eight input references. The original unfiltered donor image folders are intentionally not included. Donor names and excluded-font decisions remain in the metadata for comparison.

## Open the gallery

Extract the archive. From the extracted directory, start a local HTTP server (for example, `python3 -m http.server 8000`) and open `prefix_review.html` at the local server address. Do not open it directly as `file://`: the page loads JSON data with `fetch`.

## Protocol

- 24 target font/glyph pairs; K7-B EMA 32K; 8-shot; seed 3407.
- Prefix exclusion: after removing punctuation, exclude donor names sharing at least 8 consecutive characters and at least 60% of the longer name.
- The comparison is original K7-B versus the filtered-donor rerun.
