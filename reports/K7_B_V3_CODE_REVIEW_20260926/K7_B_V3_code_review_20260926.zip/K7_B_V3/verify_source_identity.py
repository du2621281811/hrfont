#!/usr/bin/env python3
"""Read-only SHA-256 audit for the packaged K7-B source snapshot."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
IDENTITY = SOURCE / "K7_CODE_IDENTITY.json"


def main():
    manifest = json.loads(IDENTITY.read_text())
    failures = []
    for relative_path, expected in manifest["files"].items():
        path = SOURCE / relative_path
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else "MISSING"
        if actual != expected:
            failures.append((relative_path, expected, actual))
    print(f"Manifest files: {len(manifest['files'])}; mismatches: {len(failures)}")
    for path, expected, actual in failures:
        print(f"{path}\n  expected: {expected}\n  actual:   {actual}")
    if failures:
        raise SystemExit(1)
    print("Source snapshot integrity: OK")


if __name__ == "__main__":
    main()
