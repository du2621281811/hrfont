# K7-B V3 implementation review package

This archive is for collaborators to inspect the K7-B V3 implementation and its run/configuration context. It is a source snapshot, not a ready-to-run training release.

## Contents

- `source/`: implementation snapshot, including the 438 files recorded in `source/K7_CODE_IDENTITY.json`, plus runtime policy files.
- `contracts/`: split, donor, style-pool, calibration, and V0921 availability metadata used to review data boundaries. V0921 is training-only and excluded from the donor bank.
- `provenance/`: frozen configuration and checkpoint metadata.
- `ops/`: continuation/supervision overlays for review; these are not standalone launch instructions.
- `verify_source_identity.py`: checks every file in the 438-file source identity manifest.

No font-image datasets, model/encoder weights, teacher tensors, feature caches, optimizer or EMA checkpoints, logs, predictions, or evaluation galleries are included. Paths in the frozen configurations refer to the original V100 filesystem and are not portable.

## Review

From this directory, run:

```sh
python3 verify_source_identity.py
```

The model inherits the FontDiffuser backbone and MCA-style fusion. K7-B adds CRP structural candidate routing and TC local appearance memory. The frozen training objective has zero offset-loss weight; the reported offset value is diagnostic only. Consult `source/experiments/K6/implementation/r3/scripts/` and `provenance/config_20k.json` for the implementation/configuration details.

## Source-identity limitation

The packaged source snapshot was copied from the V100 working tree on 2026-09-25. Its 438 manifest-listed files pass the included SHA-256 audit. However, the frozen training configuration records different hashes for two files, and the original training-time bytes were not recovered in the archived snapshot:

- `experiments/K6/implementation/r3/scripts/train_k6.py`
- `experiments/K6/implementation/r3/scripts/k5_runtime.py`

Therefore this package is suitable for implementation review, but must not be described as a byte-identical copy of every training-time source file or as sufficient for bit-exact reproduction. The exact data, weights, caches, and runtime dependencies also remain external.
