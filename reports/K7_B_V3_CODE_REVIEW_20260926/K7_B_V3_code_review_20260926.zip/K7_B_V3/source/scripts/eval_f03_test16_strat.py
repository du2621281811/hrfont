#!/usr/bin/env python3
"""Representative F0/F3 eval: E1 stratified protocol on test16.

Does not change sampling RNG across shards/GPUs: each (method, font, char)
calls accelerate.set_seed(3407) immediately before DPM.

GPU1 holds F2-P training — refuse it. Prefer CUDA_VISIBLE_DEVICES pointing at an
idle card (GPU2). Parallelism = one process per method, skip-existing PNGs.

Writes reports/f03_test16_strat/ only.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import sys
import time
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from PIL import Image

ROOT = Path("/root/projects/hrfont")
DATA = ROOT / "data/fontdiffuser-p253-t295-s338-cn2west-v2"
SPLIT = ROOT / "manifests/split_v3_228_16_16.json"
TEST_STEMS = ROOT / "manifests/pipeline_v3_test_stems.txt"
VAL_STEMS = ROOT / "manifests/pipeline_v3_val_stems.txt"
OUT = ROOT / "reports/f03_test16_strat"
EVAL_SPLIT = "test"


def configure_split(split: str, out: Path | None = None) -> None:
    """Point generate/metrics at test/val/train. Never mix output dirs."""
    global EVAL_SPLIT, OUT
    if split not in ("test", "val", "train"):
        raise SystemExit(f"split must be test|val|train, got {split!r}")
    EVAL_SPLIT = split
    if out is not None:
        OUT = out
    elif split == "test":
        OUT = ROOT / "reports/f03_test16_strat"
    elif split == "val":
        OUT = ROOT / "reports/f03_val16_strat"
    else:
        OUT = ROOT / "reports/f03_train_strat"
REF8 = list("永和书风骨韵天地")
REF8_CPS = [f"u{ord(c):04X}" for c in REF8]
STYLE1_CPS = [f"u{ord('永'):04X}"]
SEED = 3407
STRATIFIED = (
    list("0123456789")
    + list("AGMQRWBCO")
    + list("aodpqbegcilnu")
    + list("àéüāě")
    + list("あかさん")
    + list("アカン")
    + list("ㄅㄆㄚ")
)
BUCKET_ORDER = [
    "digit",
    "latin_upper",
    "latin_lower",
    "latin_ext",
    "hiragana",
    "katakana",
    "bopomofo",
]
METHODS = {
    "P1": {
        "label": "官方",
        "kind": "image",
        "variant": ROOT / "code/variants/cn2west_ft_v2/FontDiffuser",
        "ckpt": ROOT / "code/official/FontDiffuser/ckpt",
    },
    "E1_100k": {
        "label": "E1@100k",
        "kind": "image",
        "variant": ROOT / "code/variants/cn2west_ft_v2/FontDiffuser",
        "ckpt": ROOT / "runs/E1-FTV2-A-S3407/global_step_100000",
    },
    "F0_100k": {
        "label": "F0@100k",
        "kind": "image",
        "variant": ROOT / "code/variants/cn2west_f0_rsifree/FontDiffuser",
        "ckpt": ROOT / "runs/F0-RSIFREE-FT-A-S3407/global_step_100000",
    },
    "F0C_95000": {
        "label": "F0-CLEAN@95k(best)",
        "kind": "image",
        "variant": ROOT / "code/variants/cn2west_f0_rsifree/FontDiffuser",
        "ckpt": ROOT / "runs/F0-CLEAN-V0913-A-S3407/global_step_95000",
    },
    "F0C_100000": {
        "label": "F0-CLEAN@100k",
        "kind": "image",
        "variant": ROOT / "code/variants/cn2west_f0_rsifree/FontDiffuser",
        "ckpt": ROOT / "runs/F0-CLEAN-V0913-A-S3407/global_step_100000",
    },
    "F1_30000": {
        "label": "F1@30k",
        "kind": "f1",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F1-OFFRSI-A-S3407/global_step_30000",
    },
    "F1_80000": {
        "label": "F1@80k",
        "kind": "f1",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F1-OFFRSI-A-S3407/global_step_80000",
    },
    "F3_80k": {
        "label": "F3@80k",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F3-JOINT-DS-A-S3407/global_step_80000",
        "style_oneshot": False,
    },
    "F2_75000": {
        "label": "F2@75k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_75000",
        "style_oneshot": False,
    },
    "F2_80000": {
        "label": "F2@80k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_80000",
        "style_oneshot": False,
    },
    "F2C_40000": {
        "label": "F2-CLEAN@40k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-CLEAN-V0913-A-S3407/global_step_40000",
        "style_oneshot": False,
        "es_cache": ROOT / "artifacts/f0_clean_v0913/es_spatial",
        "ec_cache": ROOT / "artifacts/f0_clean_v0913/ec_multiscale",
    },
    "F2C_80000": {
        "label": "F2-CLEAN@80k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-CLEAN-V0913-A-S3407/global_step_80000",
        "style_oneshot": False,
        "es_cache": ROOT / "artifacts/f0_clean_v0913/es_spatial",
        "ec_cache": ROOT / "artifacts/f0_clean_v0913/ec_multiscale",
    },
    "F2_75000_s1": {
        "label": "F2@75k style1",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_75000",
        "style_oneshot": True,
        "legacy_mode_d": True,
    },
    "F2_80000_s1": {
        "label": "F2@80k style1",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_80000",
        "style_oneshot": True,
        "legacy_mode_d": True,
    },
    "F2_40000": {
        "label": "F2@40k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_40000",
        "style_oneshot": False,
    },
    "F2_40000_k1": {
        "label": "F2@40k 1-shot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_40000",
        "style_oneshot": True,
        "delta_oneshot": True,
    },
    "F2P_40000": {
        "label": "F2-P@40k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/f2_pattn_s3407/global_step_40000",
        "style_oneshot": False,
        "style_pattn": True,
    },
    "F3bP_40000": {
        "label": "F3b-P@40k",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/f3b_pattn_s3407/global_step_40000",
        "style_oneshot": False,
        "style_pattn": True,
        "support_bank": ROOT / "artifacts/f0/support_bank_f3b_topology.json",
    },
    "F3_80k_s1": {
        "label": "F3@80k style1",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F3-JOINT-DS-A-S3407/global_step_80000",
        "style_oneshot": True,
        "legacy_mode_d": True,
    },
    "F2_80000_k1": {
        "label": "F2@80k 1-shot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-DELTARSI-A-S3407/global_step_80000",
        "style_oneshot": True,
        "delta_oneshot": True,
    },
    "F2P_40000_k1": {
        "label": "F2-P@40k 1-shot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/f2_pattn_s3407/global_step_40000",
        "style_oneshot": True,
        "delta_oneshot": True,
        "style_pattn": True,
    },
    "F3_80k_k1": {
        "label": "F3@80k 1-shot",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F3-JOINT-DS-A-S3407/global_step_80000",
        "style_oneshot": True,
        "delta_oneshot": True,
    },
    "F3b_80000": {
        "label": "F3b@80k",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/f3b_topology_ownfont_s3407/global_step_80000",
        "style_oneshot": False,
        "support_bank": ROOT / "artifacts/f0/support_bank_f3b_topology.json",
    },
    "F3b_80000_k1": {
        "label": "F3b@80k 1-shot",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/f3b_topology_ownfont_s3407/global_step_80000",
        "style_oneshot": True,
        "delta_oneshot": True,
        "support_bank": ROOT / "artifacts/f0/support_bank_f3b_topology.json",
    },
    "F3bP_40000_k1": {
        "label": "F3b-P@40k 1-shot",
        "kind": "f3",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/f3b_pattn_s3407/global_step_40000",
        "style_oneshot": True,
        "delta_oneshot": True,
        "style_pattn": True,
        "support_bank": ROOT / "artifacts/f0/support_bank_f3b_topology.json",
    },
    "F2RL_40000": {
        "label": "F2-RL128@40k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-RL128-A-S3407/global_step_40000",
        "style_oneshot": False,
        "style_rl128": True,
        "es_local_cache": ROOT / "artifacts/f0/es_local_f0_block2_pool4",
    },
    "F2RL_40000_k1": {
        "label": "F2-RL128@40k 1-shot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-RL128-A-S3407/global_step_40000",
        "style_oneshot": True,
        "delta_oneshot": True,
        "style_rl128": True,
        "es_local_cache": ROOT / "artifacts/f0/es_local_f0_block2_pool4",
    },
    "F2PRL_40000": {
        "label": "F2-PRL@40k",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-PRL-A-S3407/global_step_40000",
        "style_oneshot": False,
        "style_pattn": True,
        "style_rl128": True,
        "es_local_cache": ROOT / "artifacts/f0/es_local_f0_block2_pool4",
    },
    "F2PRL_40000_k1": {
        "label": "F2-PRL@40k 1-shot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser",
        "ckpt": ROOT / "runs/F2-PRL-A-S3407/global_step_40000",
        "style_oneshot": True,
        "delta_oneshot": True,
        "style_pattn": True,
        "style_rl128": True,
        "es_local_cache": ROOT / "artifacts/f0/es_local_f0_block2_pool4",
    },
    "F2VEC_40000": {
        "label": "F2-VEC@40k fewshot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f2_vec/FontDiffuser",
        "ckpt": ROOT / "runs/F2-VEC-MT-A-S3407/global_step_40000",
        "style_oneshot": False,
    },
    "F2VEC_40000_s1": {
        "label": "F2-VEC@40k oneshot",
        "kind": "f2",
        "variant": ROOT / "code/variants/cn2west_f2_vec/FontDiffuser",
        "ckpt": ROOT / "runs/F2-VEC-MT-A-S3407/global_step_40000",
        "style_oneshot": True,
        "legacy_mode_d": True,
    },
}
F1_RUN = ROOT / "runs/F1-OFFRSI-A-S3407"
F3_VARIANT = ROOT / "code/variants/cn2west_f123_rsi/FontDiffuser"
F3_RUN = ROOT / "runs/F3-JOINT-DS-A-S3407"
F2_RUN = ROOT / "runs/F2-DELTARSI-A-S3407"
TIMELINE_STEPS = [5000, 10000, 20000, 30000, 40000, 50000, 60000, 75000, 80000]
# F2 not finished 80k yet; timeline uses whichever named ckpts exist under F2_RUN.
F2_TIMELINE_CANDIDATES = [5000, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 75000]
# All 16 test fonts; 16 chars covering every script so 9 steps stay readable.
TIMELINE_CHARS = list("08AGQaegàěあさアンㄅㄚ")
# Extra eye-probe glyphs for fonts whose ornaments live on tittles/dots (e.g. star-in-circle on i/j).
# Does not replace TIMELINE_CHARS; mid dirty/clean board shows both.
EFFECT_PROBE_CHARS = list("ij")
BOARD_CHARS = TIMELINE_CHARS + EFFECT_PROBE_CHARS


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def cp_of(ch: str) -> str:
    return f"u{ord(ch):04X}"


def fonts() -> list[str]:
    if EVAL_SPLIT == "test":
        return [l.strip() for l in TEST_STEMS.read_text().splitlines() if l.strip()]
    if EVAL_SPLIT == "val":
        return [l.strip() for l in VAL_STEMS.read_text().splitlines() if l.strip()]
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    return list(split["stems"]["train"])


def script_bucket(ch: str) -> str:
    if ch.isdigit():
        return "digit"
    name = unicodedata.name(ch, "")
    if "HIRAGANA" in name:
        return "hiragana"
    if "KATAKANA" in name:
        return "katakana"
    if "BOPOMOFO" in name:
        return "bopomofo"
    if "LATIN" in name and ch.isupper():
        return "latin_upper"
    if "LATIN" in name and ch.islower() and ord(ch) > 127:
        return "latin_ext"
    if "LATIN" in name and ch.islower():
        return "latin_lower"
    return "other"


def content_path(ch: str) -> Path:
    for sp in ("test", "val", "train"):
        p = DATA / sp / "ContentImage" / f"{cp_of(ch)}.png"
        if p.is_file():
            return p
    raise FileNotFoundError(ch)


def gt_path(stem: str, ch: str) -> Path | None:
    p = DATA / EVAL_SPLIT / "TargetImage" / stem / f"{stem}+{cp_of(ch)}.png"
    return p if p.is_file() else None


def pick_style_path(stem: str) -> Path:
    d = DATA / EVAL_SPLIT / "StyleImage" / stem
    for ch in REF8:
        p = d / f"{stem}+{cp_of(ch)}.png"
        if p.is_file():
            return p
    pngs = sorted(d.glob("*.png"))
    if not pngs:
        raise FileNotFoundError(d)
    return pngs[0]


def pred_path(mid: str, stem: str, ch: str) -> Path:
    return (
        OUT
        / "preds"
        / mid
        / EVAL_SPLIT
        / stem
        / f"{EVAL_SPLIT}__{stem}__{cp_of(ch)}__s{SEED}.png"
    )


def refuse_busy_train_gpu() -> None:
    """Refuse a physical GPU that still has an active F2-P/F3b-P train process."""
    vis = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if vis != "1":
        return
    # Training queue completed; only block if a train.py is still attached to GPU1.
    try:
        import subprocess

        out = subprocess.check_output(
            ["nvidia-smi", "--id=1", "--query-compute-apps=pid,process_name", "--format=csv,noheader"],
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return
    for line in out.splitlines():
        if "python" in line.lower() or "train" in line.lower():
            # Heuristic: still refuse when something python-like holds GPU1 during historic P training.
            raise SystemExit("refusing CUDA_VISIBLE_DEVICES=1 (busy train/eval process detected)")


def parse_shard(s: str) -> tuple[int, int]:
    i, n = s.split("/")
    i, n = int(i), int(n)
    if not (0 <= i < n):
        raise ValueError(s)
    return i, n


def shard_list(items: list[str], spec: str) -> list[str]:
    i, n = parse_shard(spec)
    return [x for k, x in enumerate(items) if k % n == i]


def update_status(patch: dict) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "status.json"
    lock_p = OUT / "status.lock"
    with lock_p.open("a+") as lf:
        fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
        cur = {}
        if path.is_file():
            try:
                cur = json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                cur = {}
        methods = cur.setdefault("methods", {})
        if "method" in patch:
            mid = patch.pop("method")
            rec = methods.setdefault(mid, {})
            rec.update(patch)
            rec["updated_at"] = utc_now()
        else:
            cur.update(patch)
        cur["updated_at"] = utc_now()
        path.write_text(json.dumps(cur, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def log(mid: str, msg: str) -> None:
    line = f"[{utc_now()}] [{mid}] {msg}"
    print(line, flush=True)
    (OUT / "logs").mkdir(parents=True, exist_ok=True)
    with (OUT / "logs" / f"{mid}.log").open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def to_tensor96(img: Image.Image, device: str):
    import torch
    import torchvision.transforms as T

    if img.size != (96, 96):
        img = img.resize((96, 96))
    t = T.Compose([T.ToTensor(), T.Normalize([0.5], [0.5])])
    return t(img.convert("RGB"))[None].to(device)


def load_image_pipe(variant: Path, ckpt_dir: Path, device: str):
    sys.path.insert(0, str(variant))
    import torch
    from src import (
        FontDiffuserDPMPipeline,
        FontDiffuserModelDPM,
        build_content_encoder,
        build_ddpm_scheduler,
        build_style_encoder,
        build_unet,
    )

    args = SimpleNamespace(
        resolution=96,
        unet_channels=(64, 128, 256, 512),
        style_image_size=(96, 96),
        content_image_size=(96, 96),
        content_encoder_downsample_size=3,
        channel_attn=True,
        content_start_channel=64,
        style_start_channel=64,
        beta_scheduler="scaled_linear",
        model_type="noise",
    )
    unet = build_unet(args=args)
    style_encoder = build_style_encoder(args=args)
    content_encoder = build_content_encoder(args=args)
    unet.load_state_dict(torch.load(ckpt_dir / "unet.pth", map_location="cpu", weights_only=True))
    style_encoder.load_state_dict(
        torch.load(ckpt_dir / "style_encoder.pth", map_location="cpu", weights_only=True)
    )
    content_encoder.load_state_dict(
        torch.load(ckpt_dir / "content_encoder.pth", map_location="cpu", weights_only=True)
    )
    model = FontDiffuserModelDPM(
        unet=unet, style_encoder=style_encoder, content_encoder=content_encoder
    ).to(device)
    model.eval()
    pipe = FontDiffuserDPMPipeline(
        model=model,
        ddpm_train_scheduler=build_ddpm_scheduler(args),
        version="V3",
        model_type="noise",
        guidance_type="classifier-free",
        guidance_scale=7.5,
    )
    return pipe, args


def sample_image(pipe, args, content_img, style_img, device: str) -> Image.Image:
    import torch
    from accelerate.utils import set_seed

    set_seed(SEED)
    with torch.no_grad():
        images = pipe.generate(
            content_images=to_tensor96(content_img, device),
            style_images=to_tensor96(style_img, device),
            batch_size=1,
            order=2,
            num_inference_step=20,
            content_encoder_downsample_size=args.content_encoder_downsample_size,
            t_start=None,
            t_end=None,
            dm_size=args.content_image_size,
            algorithm_type="dpmsolver++",
            skip_type="time_uniform",
            method="multistep",
            correcting_x0_fn=None,
        )
    im = images[0]
    if isinstance(im, Image.Image):
        return im.convert("RGB")
    arr = im.detach().cpu()
    if arr.ndim == 4:
        arr = arr[0]
    arr = ((arr.clamp(-1, 1) + 1) * 0.5 * 255).byte().permute(1, 2, 0).numpy()
    return Image.fromarray(arr)


def pack_style_delta(
    T,
    es,
    ec,
    library,
    font: str,
    ch: str,
    cfg,
    keep,
    device,
    style_oneshot: bool,
    style_pattn: bool = False,
    delta_oneshot: bool = False,
    local_cache=None,
    legacy_mode_d: bool = False,
    style_k: int | None = None,
):
    """One episode R for Es, α query, and α prototypes.

    True 1-shot: R={永}. 8-shot: R=ref8. Historical *_s1 Mode D
    (Es=永, Δ=ref8) only when legacy_mode_d=True.
    Optional style_k in 1..8 uses REF8[:k] for both Es and Δ (true-k).
    """
    if style_k is not None:
        if not 1 <= int(style_k) <= 8:
            raise ValueError(f"style_k must be 1..8, got {style_k}")
        style_refs = REF8_CPS[: int(style_k)]
        delta_refs = style_refs
    else:
        style_refs = STYLE1_CPS if style_oneshot else REF8_CPS
        delta_refs = STYLE1_CPS if delta_oneshot else REF8_CPS
    if style_refs != delta_refs and not legacy_mode_d:
        raise RuntimeError(
            f"style R and alpha R must be the same (got style={style_refs} alpha={delta_refs}); "
            "use delta_oneshot=style_oneshot, or legacy_mode_d only for historical *_s1 boards"
        )
    base = {
        "split": [EVAL_SPLIT],
        "font_stem": [font],
        "char_cp": [cp_of(ch)],
    }
    style_samples = {**base, "ref_chars": [style_refs]}
    delta_samples = {**base, "ref_chars": [delta_refs]}
    style, queries_style, style_seq, style_mask, local_raw, local_mask = T._style_conditions(
        es,
        style_samples,
        device,
        style_pattn=style_pattn,
        local_cache=local_cache,
    )
    if style_refs == delta_refs:
        queries = queries_style
        structure = T._structure_features(
            es, ec, library, style_samples, queries, cfg, keep, device
        )
        content = T._content_features(ec, style_samples, keep, device)
    else:
        _, queries, *_ = T._style_conditions(es, delta_samples, device, style_pattn=False)
        structure = T._structure_features(
            es, ec, library, delta_samples, queries, cfg, keep, device
        )
        content = T._content_features(ec, delta_samples, keep, device)
    return style, structure, content, style_seq, style_mask, local_raw, local_mask


def sidecar_style_extra(mid: str) -> dict:
    spec = METHODS[mid]
    oneshot = bool(spec.get("style_oneshot"))
    delta_oneshot = bool(spec.get("delta_oneshot"))
    legacy_mode_d = bool(spec.get("legacy_mode_d"))
    style_k = spec.get("style_k")
    if style_k is not None:
        k = int(style_k)
        style_chars = "".join(REF8[:k])
        delta_chars = style_chars
        return {
            "style_k": k,
            "delta_k": k,
            "style_chars": style_chars,
            "delta_chars": delta_chars,
            "style_oneshot": k == 1,
            "delta_oneshot": k == 1,
            "legacy_mode_d": False,
            "style_alpha_aligned": True,
        }
    if oneshot and not delta_oneshot and not legacy_mode_d:
        delta_oneshot = True
    delta_k = 1 if delta_oneshot else 8
    style_chars = "永" if oneshot else "".join(REF8)
    delta_chars = "永" if delta_oneshot else "".join(REF8)
    return {
        "style_k": 1 if oneshot else 8,
        "delta_k": delta_k,
        "style_chars": style_chars,
        "delta_chars": delta_chars,
        "style_oneshot": oneshot,
        "delta_oneshot": delta_oneshot,
        "legacy_mode_d": legacy_mode_d,
        "style_alpha_aligned": style_chars == delta_chars,
    }


def support_table(bank) -> dict:
    """_load_support_bank used to return a flat cp→list map; now wraps {table, meta}."""
    if isinstance(bank, dict) and isinstance(bank.get("table"), dict):
        return bank["table"]
    return bank


def write_sidecar(mid: str, stem: str, ch: str, style_p: Path, extra: dict | None = None) -> None:
    g = gt_path(stem, ch)
    meta = {
        "method": mid,
        "split": EVAL_SPLIT,
        "font": stem,
        "char": ch,
        "cp": cp_of(ch),
        "bucket": script_bucket(ch),
        "seed": SEED,
        "style_path": str(style_p.relative_to(ROOT)),
        "content_path": str(content_path(ch).relative_to(ROOT)),
        "gt_path": str(g.relative_to(ROOT)) if g else None,
    }
    if extra:
        meta.update(extra)
    pred_path(mid, stem, ch).with_suffix(".json").write_text(
        json.dumps(meta, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def generate_image_method(mid: str, device: str, stems: list[str], overwrite: bool) -> None:
    spec = METHODS[mid]
    n_total = len(stems) * len(STRATIFIED)
    update_status(
        {
            "method": mid,
            "phase": "running",
            "done": 0,
            "skipped": 0,
            "total": n_total,
            "label": spec["label"],
        }
    )
    log(mid, f"load {spec['ckpt']}")
    pipe, pargs = load_image_pipe(spec["variant"], spec["ckpt"], device)
    done = skipped = 0
    t0 = time.time()
    for stem in stems:
        style_p = pick_style_path(stem)
        style_img = Image.open(style_p).convert("RGB")
        for ch in STRATIFIED:
            out_p = pred_path(mid, stem, ch)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            if out_p.is_file() and not overwrite:
                skipped += 1
                continue
            pred = sample_image(pipe, pargs, Image.open(content_path(ch)).convert("RGB"), style_img, device)
            pred.save(out_p)
            write_sidecar(mid, stem, ch, style_p)
            done += 1
            if (done + skipped) % 20 == 0:
                rate = done / max(1e-6, time.time() - t0)
                eta = (n_total - done - skipped) / max(rate, 1e-6)
                update_status(
                    {
                        "method": mid,
                        "phase": "running",
                        "done": done,
                        "skipped": skipped,
                        "total": n_total,
                        "rate_per_s": round(rate, 3),
                        "eta_s": int(eta),
                        "last": f"{stem} {ch}",
                    }
                )
                log(mid, f"done={done} skipped={skipped}/{n_total} rate={rate:.2f}/s eta={eta/60:.1f}m last={stem} {ch}")
    elapsed = time.time() - t0
    update_status(
        {
            "method": mid,
            "phase": "done",
            "done": done,
            "skipped": skipped,
            "total": n_total,
            "elapsed_s": round(elapsed, 1),
        }
    )
    log(mid, f"finished done={done} skipped={skipped} elapsed={elapsed:.1f}s")


def make_dpm_adapter(fd, torch, style_pattn: bool = False):
    class DPMAdapter(torch.nn.Module):
        def __init__(self, inner, style_pattn: bool):
            super().__init__()
            self.fd = inner
            self.style_pattn = style_pattn

        def forward(self, x_t, timesteps, cond, content_encoder_downsample_size, version):
            kw = dict(
                content_images=cond[0],
                content_encoder_downsample_size=content_encoder_downsample_size,
                style_features=cond[2],
                structure_features=cond[3],
                content_features=cond[4],
                support_tokens=cond[5],
            )
            if self.style_pattn:
                kw["style_seq_tokens"] = cond[6]
                kw["style_seq_mask"] = cond[7]
            if len(cond) > 8 and cond[8] is not None:
                kw["tc_global_residual"] = cond[8]
            noise, _ = self.fd(x_t, timesteps, **kw)
            return noise

    return DPMAdapter(fd, style_pattn=style_pattn)


def cat_cond(uncond, cond):
    out = []
    for u, c in zip(uncond, cond):
        if u is None and c is None:
            out.append(None)
        elif isinstance(u, list):
            out.append([torch_cat(a, b) for a, b in zip(u, c)])
        else:
            out.append(torch_cat(u, c))
    return out


def torch_cat(a, b):
    import torch

    return torch.cat([a, b], dim=0)


def generate_f3(device: str, stems: list[str], overwrite: bool, mid: str = "F3_80k") -> None:
    import torch
    from accelerate.utils import set_seed

    spec = METHODS[mid]
    style_oneshot = bool(spec.get("style_oneshot"))
    style_pattn = bool(spec.get("style_pattn"))
    delta_oneshot = bool(spec.get("delta_oneshot"))
    legacy_mode_d = bool(spec.get("legacy_mode_d"))
    bank_path = Path(spec.get("support_bank") or (ROOT / "artifacts/f0/support_bank.json"))
    n_total = len(stems) * len(STRATIFIED)
    update_status({"method": mid, "phase": "loading", "done": 0, "skipped": 0, "total": n_total, "label": spec["label"]})
    variant = spec["variant"]
    ckpt = spec["ckpt"]
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(variant))
    os.chdir(variant)
    import train as T
    from scripts.hrfont_feature_cache import EcCache, EsCache
    from scripts.hrfont_support_adapter import SupportAdapter
    from src.build import (
        build_content_encoder,
        build_ddpm_scheduler,
        build_style_encoder,
        build_unet,
    )
    from src.dpm_solver.dpm_solver_pytorch import DPM_Solver, NoiseScheduleVP
    from src.model import FontDiffuserModel

    log(mid, f"load Es/Ec caches + LibraryEs (style_pattn={style_pattn}; bank={bank_path.name})")
    es = EsCache(ROOT / "artifacts/f0/es_spatial_f0")
    ec = EcCache(ROOT / "artifacts/f0/ec_multiscale_f0")
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    train_fonts = sorted(split["stems"]["train"])
    library = T._LibraryEs(es, train_fonts, T._style_chars_from_cache(es))
    bank = support_table(
        T._load_support_bank(
            str(bank_path),
            SimpleNamespace(support=True, support_k=8),
        )
    )
    log(mid, f"support table keys={len(bank)} style_oneshot={style_oneshot}")
    cfg = SimpleNamespace(
        rsi_source="delta",
        delta_enabled=True,
        delta_tau=0.07,
        delta_eps_alpha=0.01,
        delta_k_max=10,
        delta_k_top=10,
        delta_mode="topk",
        seed=SEED,
        support=True,
        support_k=8,
        style_start_channel=64,
    )
    args = SimpleNamespace(
        resolution=96,
        unet_channels=(64, 128, 256, 512),
        style_image_size=(96, 96),
        content_image_size=(96, 96),
        content_encoder_downsample_size=3,
        channel_attn=True,
        content_start_channel=64,
        style_start_channel=64,
        beta_scheduler="scaled_linear",
    )
    fd = FontDiffuserModel(
        unet=build_unet(args),
        style_encoder=build_style_encoder(args),
        content_encoder=build_content_encoder(args),
    )
    fd.unet.load_state_dict(torch.load(ckpt / "unet.pth", map_location="cpu", weights_only=True))
    fd.style_encoder.load_state_dict(
        torch.load(ckpt / "style_encoder.pth", map_location="cpu", weights_only=True)
    )
    fd.content_encoder.load_state_dict(
        torch.load(ckpt / "content_encoder.pth", map_location="cpu", weights_only=True)
    )
    adapter = SupportAdapter(sum(T.EC_SCALE_CHANNELS), cfg.style_start_channel * 16)
    adapter.load_state_dict(torch.load(ckpt / "support_adapter.pth", map_location="cpu", weights_only=True))
    fd.support_adapter = adapter
    T._ban_encoder_forward(fd)
    device_t = torch.device(device)
    fd.to(device_t).eval()
    model = make_dpm_adapter(fd, torch, style_pattn=style_pattn).to(device_t).eval()
    scheduler = build_ddpm_scheduler(args)
    noise_schedule = NoiseScheduleVP(schedule="discrete", betas=scheduler.betas)
    keep = torch.zeros(1, dtype=torch.bool, device=device_t)

    def pack_one(font: str, ch: str):
        style, structure, content, style_seq, style_mask, *_ = pack_style_delta(
            T,
            es,
            ec,
            library,
            font,
            ch,
            cfg,
            keep,
            device_t,
            style_oneshot,
            style_pattn=style_pattn,
            delta_oneshot=delta_oneshot,
            legacy_mode_d=legacy_mode_d,
        )
        vecs = []
        for scp in list(bank.get(cp_of(ch), []))[: cfg.support_k]:
            try:
                feats = [x.to(device_t) for x in ec.features("style", font, scp)]
            except KeyError:
                continue
            vecs.append(T._pool_ec(feats))
        pooled = torch.stack(vecs, dim=0).unsqueeze(0) if vecs else None
        return {
            "style": style,
            "structure": structure,
            "content": content,
            "support_pooled": pooled,
            "style_seq": style_seq,
            "style_mask": style_mask,
        }

    def sample_one(packed):
        set_seed(SEED)
        img = torch.zeros(1, 3, 96, 96, device=device_t)
        style = packed["style"]
        structure = packed["structure"]
        content = packed["content"]
        style_seq = packed["style_seq"]
        style_mask = packed["style_mask"]
        pooled = packed["support_pooled"]
        support = fd.support_adapter(pooled) if pooled is not None else None
        if style_pattn:
            cond = [img, img, style, structure, content, support, style_seq, style_mask]
            uncond = [
                torch.ones_like(img),
                torch.ones_like(img),
                torch.zeros_like(style),
                [torch.zeros_like(x) for x in structure],
                [torch.zeros_like(x) for x in content],
                torch.zeros_like(support) if support is not None else None,
                torch.zeros_like(style_seq),
                style_mask.clone(),
            ]
        else:
            cond = [img, img, style, structure, content, support]
            uncond = [
                torch.ones_like(img),
                torch.ones_like(img),
                torch.zeros_like(style),
                [torch.zeros_like(x) for x in structure],
                [torch.zeros_like(x) for x in content],
                torch.zeros_like(support) if support is not None else None,
            ]

        def get_t_input(t_continuous):
            return (t_continuous - 1.0 / noise_schedule.total_N) * 1000.0

        def model_fn(x, t_continuous):
            x_in = torch.cat([x, x], dim=0)
            t_in = torch.cat([t_continuous, t_continuous], dim=0)
            t_input = get_t_input(t_in)
            c_in = cat_cond(uncond, cond)
            noise_uncond, noise = model(
                x_in,
                t_input,
                c_in,
                content_encoder_downsample_size=3,
                version="V3",
            ).chunk(2)
            return noise_uncond + 7.5 * (noise - noise_uncond)

        solver = DPM_Solver(model_fn=model_fn, noise_schedule=noise_schedule, algorithm_type="dpmsolver++")
        x = torch.randn(1, 3, 96, 96, device=device_t)
        with torch.no_grad():
            x = solver.sample(x=x, steps=20, order=2, skip_type="time_uniform", method="multistep")
        x = (x / 2 + 0.5).clamp(0, 1)[0].detach().cpu().permute(1, 2, 0).numpy()
        return Image.fromarray((x * 255).round().astype("uint8"))

    done = skipped = 0
    t0 = time.time()
    update_status({"method": mid, "phase": "running", "done": 0, "skipped": 0, "total": n_total})
    for stem in stems:
        style_p = pick_style_path(stem)
        for ch in STRATIFIED:
            out_p = pred_path(mid, stem, ch)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            if out_p.is_file() and not overwrite:
                skipped += 1
                continue
            packed = pack_one(stem, ch)
            pred = sample_one(packed)
            pred.save(out_p)
            write_sidecar(mid, stem, ch, style_p, extra=sidecar_style_extra(mid))
            done += 1
            if (done + skipped) % 10 == 0:
                rate = done / max(1e-6, time.time() - t0)
                eta = (n_total - done - skipped) / max(rate, 1e-6)
                update_status(
                    {
                        "method": mid,
                        "phase": "running",
                        "done": done,
                        "skipped": skipped,
                        "total": n_total,
                        "rate_per_s": round(rate, 3),
                        "eta_s": int(eta),
                        "last": f"{stem} {ch}",
                    }
                )
                log(mid, f"done={done} skipped={skipped}/{n_total} rate={rate:.2f}/s eta={eta/60:.1f}m last={stem} {ch}")
    elapsed = time.time() - t0
    update_status(
        {
            "method": mid,
            "phase": "done",
            "done": done,
            "skipped": skipped,
            "total": n_total,
            "elapsed_s": round(elapsed, 1),
        }
    )
    log(mid, f"finished done={done} skipped={skipped} elapsed={elapsed:.1f}s")


def f3_mid(step: int) -> str:
    return "F3_80k" if step == 80000 else f"F3_{step}"


def f2_mid(step: int) -> str:
    return f"F2_{step}" if step != 75000 else "F2_75000"

def f2_mid_named(step: int, prefix: str = "F2_") -> str:
    """Pred method id. Dirty timeline uses F2_{step}; clean uses F2C_{step}."""
    if prefix == "F2_" and step == 75000:
        return "F2_75000"
    return f"{prefix}{step}"



def f2_timeline_steps(run_dir: Path | None = None) -> list[int]:
    run = Path(run_dir) if run_dir is not None else F2_RUN
    out = []
    for step in F2_TIMELINE_CANDIDATES:
        ckpt = run / f"global_step_{step}"
        if (ckpt / "unet.pth").is_file():
            out.append(step)
    # Also pick up any other named global_step_* (e.g. clean arm still below 20k).
    for p in sorted(run.glob("global_step_*")):
        try:
            step = int(p.name.split("_")[-1])
        except ValueError:
            continue
        if (p / "unet.pth").is_file() and step not in out:
            out.append(step)
    return sorted(out)


def generate_f2(device: str, stems: list[str], overwrite: bool, mid: str = "F2_75000") -> None:
    """Δ only, no Support. Es and α share one R unless spec.legacy_mode_d.
    style_pattn=True → F2-P per-ref style seq on up-path cross-attn.
    style_rl128=True → local L128. Together with style_pattn → F2-PRL (h + L, no G).
    """
    import torch
    from accelerate.utils import set_seed

    spec = METHODS[mid]
    style_oneshot = bool(spec.get("style_oneshot"))
    style_pattn = bool(spec.get("style_pattn"))
    style_rl128 = bool(spec.get("style_rl128"))
    delta_oneshot = bool(spec.get("delta_oneshot"))
    legacy_mode_d = bool(spec.get("legacy_mode_d"))
    style_k = spec.get("style_k")
    if style_k is not None:
        style_k = int(style_k)
        style_oneshot = style_k == 1
        delta_oneshot = style_k == 1
    tc_enabled = bool(spec.get("tc_enabled"))
    ref_meta_path = Path(spec["ckpt"]) / "ref_config.json"
    ref_meta = json.loads(ref_meta_path.read_text()) if ref_meta_path.exists() else {}
    n_total = len(stems) * len(STRATIFIED)
    update_status(
        {"method": mid, "phase": "loading", "done": 0, "skipped": 0, "total": n_total, "label": spec["label"]}
    )
    variant = spec["variant"]
    ckpt = spec["ckpt"]
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(variant))
    os.chdir(variant)
    import train as T
    from scripts.hrfont_feature_cache import EcCache, EsCache, EsLocalCache
    from src.build import (
        build_content_encoder,
        build_ddpm_scheduler,
        build_style_encoder,
        build_unet,
    )
    from src.dpm_solver.dpm_solver_pytorch import DPM_Solver, NoiseScheduleVP
    from src.model import FontDiffuserModel

    log(
        mid,
        f"load Es/Ec caches + LibraryEs (F2: delta, no support; "
        f"style_pattn={style_pattn}; style_rl128={style_rl128}"
        f"{'; PRL' if style_pattn and style_rl128 else ''})",
    )
    es = EsCache(Path(spec.get("es_cache") or (ROOT / "artifacts/f0/es_spatial_f0")))
    ec = EcCache(Path(spec.get("ec_cache") or (ROOT / "artifacts/f0/ec_multiscale_f0")))
    local_cache = None
    if style_rl128:
        local_dir = Path(spec.get("es_local_cache") or (ROOT / "artifacts/f0/es_local_f0_block2_pool4"))
        local_cache = EsLocalCache(local_dir)
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    train_fonts = sorted(split["stems"]["train"])
    library = T._LibraryEs(es, train_fonts, T._style_chars_from_cache(es))
    cfg = SimpleNamespace(
        rsi_source="delta",
        delta_enabled=True,
        delta_tau=0.07,
        delta_eps_alpha=0.01,
        delta_k_max=10,
        delta_k_top=10,
        delta_mode="topk",
        seed=SEED,
        support=False,
        support_k=0,
        style_start_channel=64,
    )
    if spec.get("clean_map"):
        from scripts.v0913_clean_lib import extra_exclude_indices, load_cp_group, load_donors
        donors = load_donors(spec["clean_map"])
        train_fonts = donors["all"]
        library = T._LibraryEs(es, train_fonts, T._style_chars_from_cache(es))
        cp_group = load_cp_group(spec["clean_map"])
        cfg._v0913_donor_exclude = lambda cp: extra_exclude_indices(train_fonts, cp, donors, cp_group)
    args = SimpleNamespace(
        resolution=96,
        unet_channels=(64, 128, 256, 512),
        style_image_size=(96, 96),
        content_image_size=(96, 96),
        content_encoder_downsample_size=3,
        channel_attn=True,
        content_start_channel=64,
        style_start_channel=64,
        beta_scheduler="scaled_linear",
    )
    fd = FontDiffuserModel(
        unet=build_unet(args),
        style_encoder=build_style_encoder(args),
        content_encoder=build_content_encoder(args),
    )
    if style_rl128:
        T._attach_local_proj(fd)
    if ref_meta.get("ref_aggregation"):
        T.attach_reader(fd)
        fd.ref_reader.load_state_dict(torch.load(ckpt / "ref_reader.pth", map_location="cpu", weights_only=True), strict=True)
    if ref_meta.get("local_count_norm") or spec.get("local_count_norm"):
        if not style_rl128 or style_pattn:
            raise ValueError("N requires global9+local")
        T.enable_local_count_norm(fd.unet)
    fd.unet.load_state_dict(torch.load(ckpt / "unet.pth", map_location="cpu", weights_only=True))
    fd.style_encoder.load_state_dict(
        torch.load(ckpt / "style_encoder.pth", map_location="cpu", weights_only=True)
    )
    fd.content_encoder.load_state_dict(
        torch.load(ckpt / "content_encoder.pth", map_location="cpu", weights_only=True)
    )
    if style_rl128:
        proj_p = ckpt / "local_style_proj.pth"
        if not proj_p.is_file():
            raise FileNotFoundError(proj_p)
        fd.local_style_proj.load_state_dict(torch.load(proj_p, map_location="cpu", weights_only=True))
    tc_cache = None
    if tc_enabled:
        from src import TCV2Cache, TCV2Global9Adapter, TCV2Head

        fd.tc_head = TCV2Head()
        fd.tc_global_adapter = TCV2Global9Adapter()
        for name, mod in (("tc_head.pth", fd.tc_head), ("tc_global_adapter.pth", fd.tc_global_adapter)):
            p = ckpt / name
            if not p.is_file():
                raise FileNotFoundError(p)
            mod.load_state_dict(torch.load(p, map_location="cpu", weights_only=True), strict=True)
        tc_cache = TCV2Cache(Path(spec["tc_cache"]))
        log(mid, f"TC enabled cache={spec['tc_cache']}")
    T._ban_encoder_forward(fd)
    device_t = torch.device(device)
    fd.to(device_t).eval()
    use_style_seq = style_pattn or style_rl128
    model = make_dpm_adapter(fd, torch, style_pattn=use_style_seq).to(device_t).eval()
    scheduler = build_ddpm_scheduler(args)
    noise_schedule = NoiseScheduleVP(schedule="discrete", betas=scheduler.betas)
    keep = torch.zeros(1, dtype=torch.bool, device=device_t)

    def pack_one(font: str, ch: str):
        style, structure, content, style_seq, style_mask, local_raw, local_mask = pack_style_delta(
            T,
            es,
            ec,
            library,
            font,
            ch,
            cfg,
            keep,
            device_t,
            style_oneshot,
            style_pattn=style_pattn,
            delta_oneshot=delta_oneshot,
            local_cache=local_cache,
            legacy_mode_d=legacy_mode_d,
            style_k=style_k,
        )
        n_up_prefix = 9
        if ref_meta.get("ref_aggregation"):
            refs_r = REF8_CPS[:style_k] if style_k is not None else (STYLE1_CPS if style_oneshot else REF8_CPS)
            samples_r = {"split": [EVAL_SPLIT], "font_stem": [font], "ref_chars": [refs_r]}
            style = T.apply_reader(fd, T.gather_maps(es, samples_r, device_t), samples_r)
        if style_rl128:
            prefix_seq = style_seq if style_pattn else None
            prefix_mask = style_mask if style_pattn else None
            if prefix_seq is not None:
                n_up_prefix = int(prefix_seq.shape[1])
            style_seq, style_mask = T._pack_up_style(
                fd, style, prefix_seq, prefix_mask, local_raw, local_mask, cfg_mask=None
            )
        tc_residual = None
        if tc_enabled:
            refs = REF8_CPS[:style_k] if style_k is not None else (
                STYLE1_CPS if style_oneshot else REF8_CPS
            )
            samples = {
                "split": [EVAL_SPLIT],
                "font_stem": [font],
                "char_cp": [cp_of(ch)],
                "ref_chars": [refs],
            }
            tc_residual, _, _ = T._tc_conditions(
                tc_cache, ec, samples, fd.tc_head, fd.tc_global_adapter, keep, device_t,
                include_target=False,
            )
        return {
            "style": style,
            "structure": structure,
            "content": content,
            "style_seq": style_seq,
            "style_mask": style_mask,
            "n_up_prefix": n_up_prefix,
            "tc_residual": tc_residual,
        }

    def sample_one(packed):
        set_seed(SEED)
        img = torch.zeros(1, 3, 96, 96, device=device_t)
        style = packed["style"]
        structure = packed["structure"]
        content = packed["content"]
        style_seq = packed["style_seq"]
        style_mask = packed["style_mask"]
        tc_residual = packed.get("tc_residual")
        tc_uncond = torch.zeros_like(tc_residual) if tc_residual is not None else None
        if use_style_seq:
            cond = [img, img, style, structure, content, None, style_seq, style_mask, tc_residual]
            if style_rl128:
                # RL128: zero G (9). PRL: zero P (n_max=8). Mask L off (no Linear bias leak).
                n_p = int(packed.get("n_up_prefix") or 9)
                uncond_seq = style_seq.clone()
                uncond_mask = style_mask.clone()
                uncond_seq[:, :n_p] = 0
                uncond_mask[:, n_p:] = False
                uncond = [
                    torch.ones_like(img),
                    torch.ones_like(img),
                    torch.zeros_like(style),
                    [torch.zeros_like(x) for x in structure],
                    [torch.zeros_like(x) for x in content],
                    None,
                    uncond_seq,
                    uncond_mask,
                    tc_uncond,
                ]
            else:
                uncond = [
                    torch.ones_like(img),
                    torch.ones_like(img),
                    torch.zeros_like(style),
                    [torch.zeros_like(x) for x in structure],
                    [torch.zeros_like(x) for x in content],
                    None,
                    torch.zeros_like(style_seq),
                    style_mask.clone(),
                    tc_uncond,
                ]
        else:
            cond = [img, img, style, structure, content, None, None, None, tc_residual]
            uncond = [
                torch.ones_like(img),
                torch.ones_like(img),
                torch.zeros_like(style),
                [torch.zeros_like(x) for x in structure],
                [torch.zeros_like(x) for x in content],
                None,
                None,
                None,
                tc_uncond,
            ]

        def get_t_input(t_continuous):
            return (t_continuous - 1.0 / noise_schedule.total_N) * 1000.0

        def model_fn(x, t_continuous):
            x_in = torch.cat([x, x], dim=0)
            t_in = torch.cat([t_continuous, t_continuous], dim=0)
            noise_uncond, noise = model(
                x_in,
                get_t_input(t_in),
                cat_cond(uncond, cond),
                content_encoder_downsample_size=3,
                version="V3",
            ).chunk(2)
            return noise_uncond + 7.5 * (noise - noise_uncond)

        solver = DPM_Solver(model_fn=model_fn, noise_schedule=noise_schedule, algorithm_type="dpmsolver++")
        x = torch.randn(1, 3, 96, 96, device=device_t)
        with torch.no_grad():
            x = solver.sample(x=x, steps=20, order=2, skip_type="time_uniform", method="multistep")
        x = (x / 2 + 0.5).clamp(0, 1)[0].detach().cpu().permute(1, 2, 0).numpy()
        return Image.fromarray((x * 255).round().astype("uint8"))

    done = skipped = 0
    t0 = time.time()
    update_status({"method": mid, "phase": "running", "done": 0, "skipped": 0, "total": n_total})
    for stem in stems:
        style_p = pick_style_path(stem)
        for ch in STRATIFIED:
            out_p = pred_path(mid, stem, ch)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            if out_p.is_file() and not overwrite:
                skipped += 1
                continue
            pred = sample_one(pack_one(stem, ch))
            pred.save(out_p)
            write_sidecar(mid, stem, ch, style_p, extra=sidecar_style_extra(mid))
            done += 1
            if (done + skipped) % 20 == 0:
                rate = done / max(1e-6, time.time() - t0)
                eta = (n_total - done - skipped) / max(rate, 1e-6)
                update_status(
                    {
                        "method": mid,
                        "phase": "running",
                        "done": done,
                        "skipped": skipped,
                        "total": n_total,
                        "rate_per_s": round(rate, 3),
                        "eta_s": int(eta),
                        "last": f"{stem} {ch}",
                    }
                )
                log(mid, f"done={done} skipped={skipped}/{n_total} rate={rate:.2f}/s eta={eta/60:.1f}m last={stem} {ch}")
    elapsed = time.time() - t0
    update_status(
        {
            "method": mid,
            "phase": "done",
            "done": done,
            "skipped": skipped,
            "total": n_total,
            "elapsed_s": round(elapsed, 1),
        }
    )
    log(mid, f"finished done={done} skipped={skipped} elapsed={elapsed:.1f}s")


def generate_f1(device: str, stems: list[str], overwrite: bool, mid: str = "F1_80000") -> None:
    """F1: official RSI on F0, no Support. 1-shot style (永) for Mode A fairness vs F0/E1."""
    import torch
    from accelerate.utils import set_seed

    spec = METHODS[mid]
    n_total = len(stems) * len(STRATIFIED)
    update_status(
        {"method": mid, "phase": "loading", "done": 0, "skipped": 0, "total": n_total, "label": spec["label"]}
    )
    variant = spec["variant"]
    ckpt = spec["ckpt"]
    if not (ckpt / "unet.pth").is_file():
        raise FileNotFoundError(f"F1 ckpt missing: {ckpt}")
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(variant))
    os.chdir(variant)
    import train as T
    from scripts.hrfont_feature_cache import EcCache, EsCache
    from src.build import (
        build_content_encoder,
        build_ddpm_scheduler,
        build_style_encoder,
        build_unet,
    )
    from src.dpm_solver.dpm_solver_pytorch import DPM_Solver, NoiseScheduleVP
    from src.model import FontDiffuserModel

    log(mid, f"load Es/Ec + LibraryEs (F1: official RSI, no support) ckpt={ckpt.name}")
    es = EsCache(Path(spec.get("es_cache") or (ROOT / "artifacts/f0/es_spatial_f0")))
    ec = EcCache(Path(spec.get("ec_cache") or (ROOT / "artifacts/f0/ec_multiscale_f0")))
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    train_fonts = sorted(split["stems"]["train"])
    library = T._LibraryEs(es, train_fonts, T._style_chars_from_cache(es))
    cfg = SimpleNamespace(
        rsi_source="official",
        delta_enabled=False,
        delta_tau=0.07,
        delta_eps_alpha=0.01,
        delta_k_max=10,
        delta_k_top=10,
        delta_mode="topk",
        seed=SEED,
        support=False,
        support_k=0,
        style_start_channel=64,
    )
    args = SimpleNamespace(
        resolution=96,
        unet_channels=(64, 128, 256, 512),
        style_image_size=(96, 96),
        content_image_size=(96, 96),
        content_encoder_downsample_size=3,
        channel_attn=True,
        content_start_channel=64,
        style_start_channel=64,
        beta_scheduler="scaled_linear",
    )
    fd = FontDiffuserModel(
        unet=build_unet(args),
        style_encoder=build_style_encoder(args),
        content_encoder=build_content_encoder(args),
    )
    fd.unet.load_state_dict(torch.load(ckpt / "unet.pth", map_location="cpu", weights_only=True))
    fd.style_encoder.load_state_dict(
        torch.load(ckpt / "style_encoder.pth", map_location="cpu", weights_only=True)
    )
    fd.content_encoder.load_state_dict(
        torch.load(ckpt / "content_encoder.pth", map_location="cpu", weights_only=True)
    )
    T._ban_encoder_forward(fd)
    device_t = torch.device(device)
    fd.to(device_t).eval()
    model = make_dpm_adapter(fd, torch).to(device_t).eval()
    scheduler = build_ddpm_scheduler(args)
    noise_schedule = NoiseScheduleVP(schedule="discrete", betas=scheduler.betas)
    keep = torch.zeros(1, dtype=torch.bool, device=device_t)
    # Default 1-shot (永). style_k / style_oneshot=False → REF8[:k] / REF8.
    style_k = spec.get("style_k")
    if style_k is not None:
        style_k = int(style_k)
        style_oneshot = style_k == 1
        refs = REF8_CPS[:style_k]
    else:
        style_oneshot = bool(spec.get("style_oneshot", True))
        refs = STYLE1_CPS if style_oneshot else REF8_CPS

    def pack_one(font: str, ch: str):
        samples = {
            "split": [EVAL_SPLIT],
            "font_stem": [font],
            "char_cp": [cp_of(ch)],
            "ref_chars": [refs],
        }
        style, queries, *_ = T._style_conditions(es, samples, device_t)
        structure = T._structure_features(es, ec, library, samples, queries, cfg, keep, device_t)
        content = T._content_features(ec, samples, keep, device_t)
        return {"style": style, "structure": structure, "content": content}

    def sample_one(packed):
        set_seed(SEED)
        img = torch.zeros(1, 3, 96, 96, device=device_t)
        style = packed["style"]
        structure = packed["structure"]
        content = packed["content"]
        cond = [img, img, style, structure, content, None]
        uncond = [
            torch.ones_like(img),
            torch.ones_like(img),
            torch.zeros_like(style),
            [torch.zeros_like(x) for x in structure],
            [torch.zeros_like(x) for x in content],
            None,
        ]

        def get_t_input(t_continuous):
            return (t_continuous - 1.0 / noise_schedule.total_N) * 1000.0

        def model_fn(x, t_continuous):
            x_in = torch.cat([x, x], dim=0)
            t_in = torch.cat([t_continuous, t_continuous], dim=0)
            noise_uncond, noise = model(
                x_in,
                get_t_input(t_in),
                cat_cond(uncond, cond),
                content_encoder_downsample_size=3,
                version="V3",
            ).chunk(2)
            return noise_uncond + 7.5 * (noise - noise_uncond)

        solver = DPM_Solver(model_fn=model_fn, noise_schedule=noise_schedule, algorithm_type="dpmsolver++")
        x = torch.randn(1, 3, 96, 96, device=device_t)
        with torch.no_grad():
            x = solver.sample(x=x, steps=20, order=2, skip_type="time_uniform", method="multistep")
        x = (x / 2 + 0.5).clamp(0, 1)[0].detach().cpu().permute(1, 2, 0).numpy()
        return Image.fromarray((x * 255).round().astype("uint8"))

    done = skipped = 0
    t0 = time.time()
    update_status({"method": mid, "phase": "running", "done": 0, "skipped": 0, "total": n_total})
    for stem in stems:
        style_p = pick_style_path(stem)
        for ch in STRATIFIED:
            out_p = pred_path(mid, stem, ch)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            if out_p.is_file() and not overwrite:
                skipped += 1
                continue
            pred = sample_one(pack_one(stem, ch))
            pred.save(out_p)
            write_sidecar(mid, stem, ch, style_p, extra=sidecar_style_extra(mid) if mid in METHODS else None)
            done += 1
            if (done + skipped) % 20 == 0:
                rate = done / max(1e-6, time.time() - t0)
                eta = (n_total - done - skipped) / max(rate, 1e-6)
                update_status(
                    {
                        "method": mid,
                        "phase": "running",
                        "done": done,
                        "skipped": skipped,
                        "total": n_total,
                        "rate_per_s": round(rate, 3),
                        "eta_s": int(eta),
                        "last": f"{stem} {ch}",
                    }
                )
                log(
                    mid,
                    f"done={done} skipped={skipped}/{n_total} rate={rate:.2f}/s eta={eta/60:.1f}m last={stem} {ch}",
                )
    elapsed = time.time() - t0
    update_status(
        {
            "method": mid,
            "phase": "done",
            "done": done,
            "skipped": skipped,
            "total": n_total,
            "elapsed_s": round(elapsed, 1),
        }
    )
    log(mid, f"finished done={done} skipped={skipped} elapsed={elapsed:.1f}s")


def generate_f3_timeline(device: str, overwrite: bool) -> None:
    """Sample F3 named ckpts. Conditions come from frozen F0 caches (shared across steps)."""
    import torch
    from accelerate.utils import set_seed

    stems = fonts()
    chars = TIMELINE_CHARS
    n_total = len(stems) * len(chars) * len(TIMELINE_STEPS)
    update_status(
        {
            "method": "F3_timeline",
            "phase": "loading",
            "done": 0,
            "skipped": 0,
            "total": n_total,
            "label": "F3 过程",
        }
    )
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(F3_VARIANT))
    os.chdir(F3_VARIANT)
    import train as T
    from scripts.hrfont_feature_cache import EcCache, EsCache
    from scripts.hrfont_support_adapter import SupportAdapter
    from src.build import (
        build_content_encoder,
        build_ddpm_scheduler,
        build_style_encoder,
        build_unet,
    )
    from src.dpm_solver.dpm_solver_pytorch import DPM_Solver, NoiseScheduleVP
    from src.model import FontDiffuserModel

    log("F3_timeline", "load Es/Ec caches")
    es = EsCache(ROOT / "artifacts/f0/es_spatial_f0")
    ec = EcCache(ROOT / "artifacts/f0/ec_multiscale_f0")
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    train_fonts = sorted(split["stems"]["train"])
    library = T._LibraryEs(es, train_fonts, T._style_chars_from_cache(es))
    bank = support_table(
        T._load_support_bank(
            str(ROOT / "artifacts/f0/support_bank.json"),
            SimpleNamespace(support=True, support_k=8),
        )
    )
    log("F3_timeline", f"support table keys={len(bank)}")
    cfg = SimpleNamespace(
        rsi_source="delta", delta_enabled=True, delta_tau=0.07, delta_eps_alpha=0.01,
        delta_k_max=10, delta_k_top=10, delta_mode="topk", seed=SEED, support=True,
        support_k=8, style_start_channel=64,
    )
    args = SimpleNamespace(
        resolution=96, unet_channels=(64, 128, 256, 512),
        style_image_size=(96, 96), content_image_size=(96, 96),
        content_encoder_downsample_size=3, channel_attn=True,
        content_start_channel=64, style_start_channel=64, beta_scheduler="scaled_linear",
    )
    device_t = torch.device(device)
    fd = FontDiffuserModel(
        unet=build_unet(args),
        style_encoder=build_style_encoder(args),
        content_encoder=build_content_encoder(args),
    )
    adapter = SupportAdapter(sum(T.EC_SCALE_CHANNELS), cfg.style_start_channel * 16)
    fd.support_adapter = adapter
    T._ban_encoder_forward(fd)
    fd.to(device_t).eval()
    model = make_dpm_adapter(fd, torch).to(device_t).eval()
    scheduler = build_ddpm_scheduler(args)
    noise_schedule = NoiseScheduleVP(schedule="discrete", betas=scheduler.betas)
    keep = torch.zeros(1, dtype=torch.bool, device=device_t)

    def pack_one(font: str, ch: str):
        samples = {
            "split": ["test"], "font_stem": [font], "char_cp": [cp_of(ch)],
            "ref_chars": [[f"u{ord(c):04X}" for c in "永和书风骨韵天地"]],
        }
        style, queries, *_ = T._style_conditions(es, samples, device_t)
        structure = T._structure_features(es, ec, library, samples, queries, cfg, keep, device_t)
        content = T._content_features(ec, samples, keep, device_t)
        vecs = []
        for scp in list(bank.get(cp_of(ch), []))[: cfg.support_k]:
            try:
                feats = [x.to(device_t) for x in ec.features("style", font, scp)]
            except KeyError:
                continue
            vecs.append(T._pool_ec(feats))
        pooled = torch.stack(vecs, dim=0).unsqueeze(0) if vecs else None
        return {"style": style, "structure": structure, "content": content, "support_pooled": pooled}

    log("F3_timeline", f"precompute conditions fonts={len(stems)} chars={len(chars)}")
    packed_map = {}
    for stem in stems:
        for ch in chars:
            packed_map[(stem, ch)] = pack_one(stem, ch)

    done = skipped = 0
    t0 = time.time()
    for step in TIMELINE_STEPS:
        mid = f3_mid(step)
        ckpt = F3_RUN / f"global_step_{step}"
        log("F3_timeline", f"load {ckpt}")
        fd.unet.load_state_dict(torch.load(ckpt / "unet.pth", map_location="cpu", weights_only=True))
        fd.style_encoder.load_state_dict(
            torch.load(ckpt / "style_encoder.pth", map_location="cpu", weights_only=True)
        )
        fd.content_encoder.load_state_dict(
            torch.load(ckpt / "content_encoder.pth", map_location="cpu", weights_only=True)
        )
        adapter.load_state_dict(torch.load(ckpt / "support_adapter.pth", map_location="cpu", weights_only=True))
        adapter.to(device_t)
        fd.to(device_t).eval()

        def sample_one(p):
            set_seed(SEED)
            img = torch.zeros(1, 3, 96, 96, device=device_t)
            support = fd.support_adapter(p["support_pooled"]) if p["support_pooled"] is not None else None
            cond = [img, img, p["style"], p["structure"], p["content"], support]
            uncond = [
                torch.ones_like(img), torch.ones_like(img), torch.zeros_like(p["style"]),
                [torch.zeros_like(x) for x in p["structure"]],
                [torch.zeros_like(x) for x in p["content"]],
                torch.zeros_like(support) if support is not None else None,
            ]

            def get_t_input(t_continuous):
                return (t_continuous - 1.0 / noise_schedule.total_N) * 1000.0

            def model_fn(x, t_continuous):
                x_in = torch.cat([x, x], dim=0)
                t_in = torch.cat([t_continuous, t_continuous], dim=0)
                noise_uncond, noise = model(
                    x_in, get_t_input(t_in), cat_cond(uncond, cond),
                    content_encoder_downsample_size=3, version="V3",
                ).chunk(2)
                return noise_uncond + 7.5 * (noise - noise_uncond)

            solver = DPM_Solver(model_fn=model_fn, noise_schedule=noise_schedule, algorithm_type="dpmsolver++")
            x = torch.randn(1, 3, 96, 96, device=device_t)
            with torch.no_grad():
                x = solver.sample(x=x, steps=20, order=2, skip_type="time_uniform", method="multistep")
            x = (x / 2 + 0.5).clamp(0, 1)[0].detach().cpu().permute(1, 2, 0).numpy()
            return Image.fromarray((x * 255).round().astype("uint8"))

        for stem in stems:
            style_p = pick_style_path(stem)
            for ch in chars:
                out_p = pred_path(mid, stem, ch)
                out_p.parent.mkdir(parents=True, exist_ok=True)
                if out_p.is_file() and not overwrite:
                    skipped += 1
                    continue
                pred = sample_one(packed_map[(stem, ch)])
                pred.save(out_p)
                write_sidecar(mid, stem, ch, style_p)
                done += 1
                if (done + skipped) % 20 == 0:
                    rate = done / max(1e-6, time.time() - t0)
                    eta = (n_total - done - skipped) / max(rate, 1e-6)
                    update_status(
                        {
                            "method": "F3_timeline",
                            "phase": "running",
                            "done": done,
                            "skipped": skipped,
                            "total": n_total,
                            "rate_per_s": round(rate, 3),
                            "eta_s": int(eta),
                            "last": f"{step} {stem} {ch}",
                        }
                    )
                    log("F3_timeline", f"step={step} done={done} skipped={skipped}/{n_total} rate={rate:.2f}/s eta={eta/60:.1f}m")
    elapsed = time.time() - t0
    update_status(
        {
            "method": "F3_timeline",
            "phase": "done",
            "done": done,
            "skipped": skipped,
            "total": n_total,
            "elapsed_s": round(elapsed, 1),
        }
    )
    log("F3_timeline", f"finished done={done} skipped={skipped} elapsed={elapsed:.1f}s")
    write_timeline_html()


def write_timeline_html() -> None:
    steps = TIMELINE_STEPS
    mids = [f3_mid(s) for s in steps]
    items = []
    for stem in fonts():
        for ch in TIMELINE_CHARS:
            preds = {f3_mid(s): f"preds/{f3_mid(s)}/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png" for s in steps}
            items.append(
                {
                    "font": stem,
                    "char": ch,
                    "cp": cp_of(ch),
                    "bucket": script_bucket(ch),
                    "content": f"refs/content/{cp_of(ch)}.png",
                    "style": f"refs/style/{stem}.png",
                    "gt": f"refs/gt/{stem}+{cp_of(ch)}.png",
                    "f0": f"preds/F0_100k/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "preds": preds,
                }
            )
    payload = {
        "fonts": fonts(),
        "chars": TIMELINE_CHARS,
        "steps": steps,
        "mids": mids,
        "items": items,
    }
    html = f"""<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<meta http-equiv="refresh" content="25"/>
<title>F3 训练过程 · test16</title>
<style>
:root{{--bg:#eef1f5;--card:#fff;--line:#d5dbe3;--muted:#5c6570;--ink:#1a1a1a;--accent:#1f4a6f}}
*{{box-sizing:border-box}} body{{margin:0;font:14px/1.45 system-ui,"Noto Sans SC",sans-serif;background:var(--bg);color:var(--ink)}}
header{{background:var(--card);border-bottom:1px solid var(--line);padding:14px 18px}}
h1{{margin:0;font-size:1.2rem}} .meta{{color:var(--muted);font-size:12px;margin-top:4px}}
main{{max-width:1400px;margin:16px auto;padding:0 14px 48px}}
.note{{background:#fff8e8;border:1px solid #e6d7a8;padding:8px 10px;margin:10px 0;font-size:12px}}
select{{padding:6px 8px;border:1px solid var(--line);background:#fff;margin-right:6px}}
.grid{{overflow-x:auto}}
table.g th,table.g td{{border:1px solid var(--line);padding:3px;text-align:center;vertical-align:bottom;font-size:11px;color:var(--muted)}}
table.g img{{width:72px;height:72px;image-rendering:pixelated;display:block;background:#fff}}
table.g td.ch{{font:700 15px/1.2 ui-serif,serif;color:var(--ink)}}
a{{color:var(--accent)}}
pre{{white-space:pre-wrap}}
</style></head><body>
<header>
  <h1>F3 从 5k 到 80k 的变化</h1>
  <div class="meta">test16 套字体 · 16 个跨语种字符 · 同一 DPM++20 / CFG7.5 / seed 3407 · <a href="./">返回终点评测</a></div>
</header>
<main>
<div class="note">左两列是 GT 与父模型 F0@100k。后面每一列是 F3 的一个 checkpoint。条件始终是 cache Δ + Support×8，只有 UNet/RSI 头在变。5k 刚过 warmup。75k 是 trainer val 最好，80k 是终点。</div>
<section><pre id="prog" class="meta">读取进度…</pre></section>
<p>
  <label>字体 <select id="font"></select></label>
  <label>语种 <select id="bucket"><option value="">全部</option></select></label>
</p>
<div class="grid" id="sheet"></div>
</main>
<script>
const DATA = {json.dumps(payload, ensure_ascii=False)};
const BNAME = {{digit:'数字', latin_upper:'拉丁大写', latin_lower:'拉丁小写', latin_ext:'拉丁扩展', hiragana:'平假名', katakana:'片假名', bopomofo:'注音'}};
const fontSel = document.getElementById('font');
const bucketSel = document.getElementById('bucket');
DATA.fonts.forEach(f => {{ const o=document.createElement('option'); o.value=f; o.textContent=f; fontSel.appendChild(o); }});
[...new Set(DATA.items.map(i=>i.bucket))].forEach(b => {{ const o=document.createElement('option'); o.value=b; o.textContent=BNAME[b]||b; bucketSel.appendChild(o); }});
function render(){{
  const font=fontSel.value, bucket=bucketSel.value;
  const items=DATA.items.filter(it=>it.font===font && (!bucket || it.bucket===bucket));
  const heads=['字','Content','GT','F0@100k'].concat(DATA.steps.map(s=>'F3@'+(s/1000)+'k'));
  let h='<table class="g"><thead><tr>'+heads.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>';
  for (const it of items){{
    h += '<tr><td class="ch">'+it.char+'</td>';
    h += '<td><img src="'+it.content+'"/></td><td><img src="'+it.gt+'"/></td><td><img src="'+it.f0+'"/></td>';
    for (const mid of DATA.mids){{
      h += '<td><img src="'+it.preds[mid]+'" onerror="this.style.opacity=.2"/></td>';
    }}
    h += '</tr>';
  }}
  document.getElementById('sheet').innerHTML = h+'</tbody></table>';
}}
fontSel.onchange=render; bucketSel.onchange=render; render();
async function tick(){{
  try {{
    const s = await (await fetch('status.json?t='+Date.now(),{{cache:'no-store'}})).json();
    const v = (s.methods||{{}}).F3_timeline || {{}};
    const tot=v.total||0, d=(v.done||0)+(v.skipped||0);
    const pct = tot? Math.round(100*d/tot):0;
    let t = (v.phase||'')+' '+d+'/'+tot+' ('+pct+'%)';
    if (v.eta_s) t += '  ETA '+Math.round(v.eta_s/60)+' min';
    if (v.last) t += '  '+v.last;
    document.getElementById('prog').textContent = t;
  }} catch(e) {{ document.getElementById('prog').textContent = String(e); }}
}}
tick(); setInterval(tick, 8000);
</script>
</body></html>
"""
    (OUT / "timeline.html").write_text(html, encoding="utf-8")
    print("wrote", OUT / "timeline.html", "items", len(items))


def generate_f2_timeline(
    device: str,
    overwrite: bool,
    stems: list[str] | None = None,
    steps: list[int] | None = None,
    status_key: str = "F2_timeline",
    run_dir: Path | None = None,
    es_dir: Path | None = None,
    ec_dir: Path | None = None,
    mid_prefix: str = "F2_",
    chars: list[str] | None = None,
) -> None:
    """Sample F2 named ckpts with train-matched Δ conditions (no Support).

    Font/step sharding is result-safe: each (font,char,step) calls set_seed(3407).
    Optional run_dir/es_dir/ec_dir/mid_prefix select the clean arm without changing
    sampler (DPM++20 / CFG7.5 / seed 3407 / TIMELINE_CHARS / test16 fonts).
    """
    import torch
    from accelerate.utils import set_seed

    run = Path(run_dir) if run_dir is not None else F2_RUN
    es_path = Path(es_dir) if es_dir is not None else (ROOT / "artifacts/f0/es_spatial_f0")
    ec_path = Path(ec_dir) if ec_dir is not None else (ROOT / "artifacts/f0/ec_multiscale_f0")
    steps = list(steps) if steps is not None else f2_timeline_steps(run)
    if not steps:
        raise SystemExit(f"no F2 checkpoints under {run}")
    stems = list(stems) if stems is not None else fonts()
    chars = list(chars) if chars is not None else list(TIMELINE_CHARS)
    n_total = len(stems) * len(chars) * len(steps)
    update_status(
        {
            "method": status_key,
            "phase": "loading",
            "done": 0,
            "skipped": 0,
            "total": n_total,
            "label": f"F2 过程:{status_key}",
            "stems": stems,
            "steps": steps,
            "run": str(run),
            "es": str(es_path),
            "ec": str(ec_path),
            "mid_prefix": mid_prefix,
        }
    )
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(F3_VARIANT))
    os.chdir(F3_VARIANT)
    import train as T
    from scripts.hrfont_feature_cache import EcCache, EsCache
    from src.build import (
        build_content_encoder,
        build_ddpm_scheduler,
        build_style_encoder,
        build_unet,
    )
    from src.dpm_solver.dpm_solver_pytorch import DPM_Solver, NoiseScheduleVP
    from src.model import FontDiffuserModel

    log(
        status_key,
        f"load Es/Ec caches; run={run.name} es={es_path.name} steps={steps} stems={len(stems)} prefix={mid_prefix}",
    )
    es = EsCache(es_path)
    ec = EcCache(ec_path)
    split = json.loads(SPLIT.read_text(encoding="utf-8"))
    train_fonts = sorted(split["stems"]["train"])
    library = T._LibraryEs(es, train_fonts, T._style_chars_from_cache(es))
    cfg = SimpleNamespace(
        rsi_source="delta",
        delta_enabled=True,
        delta_tau=0.07,
        delta_eps_alpha=0.01,
        delta_k_max=10,
        delta_k_top=10,
        delta_mode="topk",
        seed=SEED,
        support=False,
        support_k=0,
        style_start_channel=64,
    )
    args = SimpleNamespace(
        resolution=96,
        unet_channels=(64, 128, 256, 512),
        style_image_size=(96, 96),
        content_image_size=(96, 96),
        content_encoder_downsample_size=3,
        channel_attn=True,
        content_start_channel=64,
        style_start_channel=64,
        beta_scheduler="scaled_linear",
    )
    device_t = torch.device(device)
    fd = FontDiffuserModel(
        unet=build_unet(args),
        style_encoder=build_style_encoder(args),
        content_encoder=build_content_encoder(args),
    )
    T._ban_encoder_forward(fd)
    fd.to(device_t).eval()
    model = make_dpm_adapter(fd, torch).to(device_t).eval()
    scheduler = build_ddpm_scheduler(args)
    noise_schedule = NoiseScheduleVP(schedule="discrete", betas=scheduler.betas)
    keep = torch.zeros(1, dtype=torch.bool, device=device_t)

    def pack_one(font: str, ch: str):
        samples = {
            "split": [EVAL_SPLIT],
            "font_stem": [font],
            "char_cp": [cp_of(ch)],
            "ref_chars": [[f"u{ord(c):04X}" for c in "永和书风骨韵天地"]],
        }
        style, queries, *_ = T._style_conditions(es, samples, device_t)
        structure = T._structure_features(es, ec, library, samples, queries, cfg, keep, device_t)
        content = T._content_features(ec, samples, keep, device_t)
        return {"style": style, "structure": structure, "content": content}

    log(status_key, f"precompute conditions fonts={len(stems)} chars={len(chars)}")
    packed_map = {}
    for stem in stems:
        for ch in chars:
            packed_map[(stem, ch)] = pack_one(stem, ch)

    done = skipped = 0
    t0 = time.time()
    for step in steps:
        mid = f2_mid_named(step, mid_prefix)
        ckpt = run / f"global_step_{step}"
        log(status_key, f"load {ckpt}")
        fd.unet.load_state_dict(torch.load(ckpt / "unet.pth", map_location="cpu", weights_only=True))
        fd.style_encoder.load_state_dict(
            torch.load(ckpt / "style_encoder.pth", map_location="cpu", weights_only=True)
        )
        fd.content_encoder.load_state_dict(
            torch.load(ckpt / "content_encoder.pth", map_location="cpu", weights_only=True)
        )
        fd.to(device_t).eval()

        def sample_one(p):
            set_seed(SEED)
            img = torch.zeros(1, 3, 96, 96, device=device_t)
            cond = [img, img, p["style"], p["structure"], p["content"], None]
            uncond = [
                torch.ones_like(img),
                torch.ones_like(img),
                torch.zeros_like(p["style"]),
                [torch.zeros_like(x) for x in p["structure"]],
                [torch.zeros_like(x) for x in p["content"]],
                None,
            ]

            def get_t_input(t_continuous):
                return (t_continuous - 1.0 / noise_schedule.total_N) * 1000.0

            def model_fn(x, t_continuous):
                x_in = torch.cat([x, x], dim=0)
                t_in = torch.cat([t_continuous, t_continuous], dim=0)
                noise_uncond, noise = model(
                    x_in,
                    get_t_input(t_in),
                    cat_cond(uncond, cond),
                    content_encoder_downsample_size=3,
                    version="V3",
                ).chunk(2)
                return noise_uncond + 7.5 * (noise - noise_uncond)

            solver = DPM_Solver(model_fn=model_fn, noise_schedule=noise_schedule, algorithm_type="dpmsolver++")
            x = torch.randn(1, 3, 96, 96, device=device_t)
            with torch.no_grad():
                x = solver.sample(x=x, steps=20, order=2, skip_type="time_uniform", method="multistep")
            x = (x / 2 + 0.5).clamp(0, 1)[0].detach().cpu().permute(1, 2, 0).numpy()
            return Image.fromarray((x * 255).round().astype("uint8"))

        for stem in stems:
            style_p = pick_style_path(stem)
            for ch in chars:
                out_p = pred_path(mid, stem, ch)
                out_p.parent.mkdir(parents=True, exist_ok=True)
                if out_p.is_file() and not overwrite:
                    skipped += 1
                    continue
                pred = sample_one(packed_map[(stem, ch)])
                pred.save(out_p)
                write_sidecar(mid, stem, ch, style_p)
                done += 1
                if (done + skipped) % 20 == 0:
                    rate = done / max(1e-6, time.time() - t0)
                    eta = (n_total - done - skipped) / max(rate, 1e-6)
                    update_status(
                        {
                            "method": status_key,
                            "phase": "running",
                            "done": done,
                            "skipped": skipped,
                            "total": n_total,
                            "rate_per_s": round(rate, 3),
                            "eta_s": int(eta),
                            "last": f"{step} {stem} {ch}",
                        }
                    )
                    log(
                        status_key,
                        f"step={step} done={done} skipped={skipped}/{n_total} rate={rate:.2f}/s eta={eta/60:.1f}m",
                    )
    elapsed = time.time() - t0
    update_status(
        {
            "method": status_key,
            "phase": "done",
            "done": done,
            "skipped": skipped,
            "total": n_total,
            "elapsed_s": round(elapsed, 1),
        }
    )
    log(status_key, f"finished done={done} skipped={skipped} elapsed={elapsed:.1f}s")
    if mid_prefix == "F2_":
        write_f2_timeline_html()
    else:
        write_f2_clean_compare_html()


def write_f2_clean_compare_html() -> None:
    """Dirty F2_* vs clean F2C_* mid boards (same protocol)."""
    clean_run = ROOT / "runs/F2-CLEAN-V0913-A-S3407"
    dirty_steps = set(f2_timeline_steps(F2_RUN))
    clean_steps = set(f2_timeline_steps(clean_run))
    steps_clean = sorted(
        s for s in (dirty_steps | clean_steps) if (OUT / f"preds/{f2_mid_named(s, 'F2C_')}").is_dir()
    )
    steps_dirty = sorted(
        s for s in (dirty_steps | clean_steps) if (OUT / f"preds/{f2_mid_named(s, 'F2_')}").is_dir()
    )
    steps = sorted(set(steps_clean) | set(steps_dirty))
    if not steps:
        steps = steps_clean or steps_dirty
    board_chars = list(BOARD_CHARS)
    items = []
    for stem in fonts():
        for ch in board_chars:
            preds = {}
            for s in steps:
                preds[f"dirty_{s}"] = f"preds/{f2_mid_named(s, 'F2_')}/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png"
                preds[f"clean_{s}"] = f"preds/{f2_mid_named(s, 'F2C_')}/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png"
            items.append(
                {
                    "font": stem,
                    "char": ch,
                    "cp": cp_of(ch),
                    "bucket": script_bucket(ch),
                    "probe": ch in EFFECT_PROBE_CHARS,
                    "content": f"refs/content/{cp_of(ch)}.png",
                    "gt": f"refs/gt/{stem}+{cp_of(ch)}.png",
                    "f0_dirty": f"preds/F0_100k/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "f0_clean_100k": f"preds/F0C_100000/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "f0_clean_95k": f"preds/F0C_95000/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "f0_clean": f"preds/F0C_100000/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "preds": preds,
                }
            )
    style_ref8 = {
        stem: [
            {"ch": c, "cp": cp_of(c), "src": f"refs/style_ref8/{stem}/{cp_of(c)}.png"}
            for c in REF8
        ]
        for stem in fonts()
    }
    payload = {
        "fonts": fonts(),
        "chars": board_chars,
        "effect_probe": EFFECT_PROBE_CHARS,
        "steps": steps,
        "steps_dirty": steps_dirty,
        "steps_clean": steps_clean,
        "ref8": "".join(REF8),
        "style_ref8": style_ref8,
        "items": items,
        "note": "F2 dirty vs F2-CLEAN mid; F0 dirty@100k vs clean@100k + clean@95k best; 8-shot; +i/j",
    }
    html = f"""<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>F2 dirty vs CLEAN 中间测试图</title>
<style>
:root{{--bg:#eef1f5;--card:#fff;--line:#d5dbe3;--muted:#5c6570;--ink:#1a1a1a;--accent:#1f4a6f;--dirty:#8b3a2a;--clean:#1f5a3a;--cell:80px}}
*{{box-sizing:border-box}} html,body{{height:100%;margin:0}}
body{{font:13px/1.4 system-ui,sans-serif;background:var(--bg);color:var(--ink);display:flex;flex-direction:column;height:100vh;overflow:hidden}}
.top{{z-index:40;background:var(--bg);border-bottom:1px solid var(--line);flex:0 1 auto;max-height:38vh;overflow:auto}}
header{{background:var(--card);padding:6px 10px}}
h1{{margin:0;font-size:1.05rem}} .meta{{color:var(--muted);font-size:11px;margin-top:2px}}
.note{{display:none;background:#fff8e8;border-top:1px solid #e6d7a8;padding:6px 12px;font-size:11px}}
.note.on{{display:block}}
.panel{{background:var(--card);padding:6px 10px;display:grid;gap:4px}}
.row{{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center}}
.grp{{display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--muted)}}
.grp strong{{color:var(--ink);font-weight:600}}
select,button,input[type=range]{{padding:4px 7px;border:1px solid var(--line);background:#fff;border-radius:4px;font:inherit}}
button{{cursor:pointer}} button:hover{{border-color:var(--accent)}}
button.active{{background:#e8f0f7;border-color:var(--accent);color:var(--accent)}}
.chk{{display:inline-flex;align-items:center;gap:3px;font-size:12px;color:var(--muted);cursor:pointer}}
.chips{{display:flex;flex-wrap:nowrap;gap:3px;overflow-x:auto;max-width:100%;padding-bottom:2px}}
.chips.wrap{{flex-wrap:wrap}}
.chip{{padding:2px 7px;border:1px solid var(--line);border-radius:999px;background:#f4f6f8;font-size:11px;cursor:pointer;user-select:none;color:var(--muted)}}
.chip.on{{background:#dceaf6;border-color:var(--accent);color:var(--accent);font-weight:600}}
details.more{{border-top:1px dashed var(--line);padding-top:4px}}
details.more > summary{{cursor:pointer;font-size:12px;color:var(--accent);user-select:none}}
.ref8{{flex:0 0 auto;background:var(--card);border-bottom:1px solid var(--line);padding:6px 10px;overflow-x:auto}}
.ref8 .lab{{font-size:12px;font-weight:600;color:var(--ink);margin-bottom:4px}}
.ref8 .lab span{{font-weight:400;color:var(--muted)}}
.ref8 .figs{{display:flex;gap:6px;align-items:flex-end;flex-wrap:nowrap}}
.ref8 figure{{margin:0;text-align:center}}
.ref8 figcaption{{font-size:10px;color:var(--muted);margin-top:1px}}
.ref8 img{{width:56px;height:56px;image-rendering:pixelated;display:block;background:#fff;border:1px solid var(--line);cursor:zoom-in}}
#prog{{margin:0;color:var(--muted);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}}
.grid-wrap{{flex:1 1 auto;min-height:0;padding:8px 10px 12px;display:flex;flex-direction:column}}
.grid{{flex:1 1 auto;overflow:auto;border:1px solid var(--line);background:var(--card);min-height:200px}}
table.g{{border-collapse:separate;border-spacing:0}}
table.g th,table.g td{{border-right:1px solid var(--line);border-bottom:1px solid var(--line);padding:2px;text-align:center;vertical-align:bottom;font-size:10px;color:var(--muted);background:#fff}}
table.g thead th{{position:sticky;top:0;z-index:5;background:#f7f9fb;box-shadow:0 1px 0 var(--line)}}
table.g th.pair-d{{color:var(--dirty);background:#faf3f1}}
table.g th.pair-c{{color:var(--clean);background:#f1f7f3}}
table.g td.sticky,table.g th.sticky{{position:sticky;left:0;z-index:3;background:#fff;min-width:1.8em;box-shadow:1px 0 0 var(--line)}}
table.g thead th.sticky{{z-index:6;background:#f7f9fb}}
table.g th.sep,table.g td.sep{{border-left:2px solid #9aa8b8}}
table.g img{{width:var(--cell);height:var(--cell);image-rendering:pixelated;display:block;background:#fff;cursor:zoom-in}}
table.g td.ch{{font:700 14px/1.1 ui-serif,serif;color:var(--ink)}}
table.g td.pair-d{{background:#fffaf8}}
table.g td.pair-c{{background:#f7fcf8}}
a{{color:var(--accent)}}
#lightbox{{display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:100;align-items:center;justify-content:center;padding:24px}}
#lightbox.on{{display:flex}}
#lightbox .box{{background:#fff;padding:12px;border-radius:8px;max-width:96vw;max-height:92vh;overflow:auto;text-align:center}}
#lightbox img{{max-width:min(640px,90vw);max-height:70vh;image-rendering:pixelated;background:#fff}}
#lightbox .cap{{margin-top:8px;font-size:13px;color:var(--muted)}}
#lightbox .nav{{display:flex;gap:8px;justify-content:center;margin-top:10px}}
</style></head><body>
<div class="top" id="topbar">
<header>
  <h1>F2 中间测试图 · 脏臂 vs F2-CLEAN
    <button type="button" id="toggleNote" style="font-size:11px;margin-left:8px;vertical-align:middle">说明</button>
  </h1>
  <div class="meta">test16 · DPM++20 / CFG7.5 / seed3407 · 8-shot ·
    <a href="timeline_f2.html">脏 F2 时间线</a> · <a href="./">终点评测</a>
    · <a href="clean_dirty_compare.html">干净vs脏指标</a>
    · ←/→ 换字体 · 点图放大</div>
</header>
<div class="note" id="note">Style×8 = Es+Δ（{"".join(REF8)}）。F0：脏@100k 与 <b>净@100k</b> 同预算；<b>净@95k</b> 为 val-best / F2-CLEAN 父模型。默认只开关键 step（5/40/80k），避免列过多。</div>
<section class="panel" id="controls">
  <div class="row">
    <div class="grp"><strong>字体</strong>
      <button type="button" id="fontPrev" title="上一字体">‹</button>
      <select id="font"></select>
      <button type="button" id="fontNext" title="下一字体">›</button>
    </div>
    <div class="grp"><strong>语种</strong>
      <select id="bucket"><option value="">全部</option><option value="__effect__">特效 i/j</option></select>
    </div>
    <div class="grp"><strong>布局</strong>
      <select id="layout">
        <option value="pair">成对并排</option>
        <option value="dirty">只看脏</option>
        <option value="clean">只看净</option>
        <option value="interleave">交错全列</option>
      </select>
    </div>
    <div class="grp"><strong>图</strong>
      <input type="range" id="cellSize" min="48" max="140" step="8" value="80"/>
      <span id="cellSizeVal">80</span>
    </div>
    <button type="button" id="reloadImgs">刷新</button>
    <button type="button" id="presetKey" class="active" title="5/40/80k">预设·关键</button>
    <button type="button" id="presetF0">预设·F0</button>
    <button type="button" id="presetAll">预设·全部</button>
  </div>
  <div class="row">
    <strong style="font-size:12px">基准</strong>
    <label class="chk"><input type="checkbox" id="showContent" checked/> Content</label>
    <label class="chk"><input type="checkbox" id="showGt" checked/> GT</label>
    <label class="chk"><input type="checkbox" id="showF0d" checked/> F0脏@100k</label>
    <label class="chk"><input type="checkbox" id="showF0c100" checked/> F0净@100k</label>
    <label class="chk"><input type="checkbox" id="showF0c95"/> F0净@95k</label>
  </div>
  <div class="row">
    <strong style="font-size:12px">step</strong>
    <div class="chips" id="stepChips"></div>
    <button type="button" id="stepsAll">全</button>
    <button type="button" id="stepsNone">清</button>
  </div>
  <details class="more" id="charDetails">
    <summary>字符筛选（默认全选；可收起）</summary>
    <div class="row" style="margin-top:4px">
      <div class="chips" id="charChips"></div>
      <button type="button" id="charsAll">全选</button>
      <button type="button" id="charsProbe">仅 i/j</button>
    </div>
  </details>
  <pre id="prog">…</pre>
</section>
</div>
<section class="ref8" id="ref8box">
  <div class="lab" id="ref8lab">Style×8 · Es+Δ 风格条件 · {"".join(REF8)}</div>
  <div class="figs" id="ref8figs"></div>
</section>
<div class="grid-wrap"><div class="grid" id="sheet"></div></div>
<div id="lightbox"><div class="box">
  <img id="lbImg" alt=""/>
  <div class="cap" id="lbCap"></div>
  <div class="nav">
    <button type="button" id="lbPrev">上一张</button>
    <button type="button" id="lbClose">关闭 · Esc</button>
    <button type="button" id="lbNext">下一张</button>
  </div>
</div></div>
<script>
const DATA = {json.dumps(payload, ensure_ascii=False)};
const LS = 'f2c_mid_ui_v5';
const KEY_STEPS = [5000, 40000, 80000];
const BNAME = {{digit:'数字', latin_upper:'拉丁大写', latin_lower:'拉丁小写', latin_ext:'拉丁扩展', hiragana:'平假名', katakana:'片假名', bopomofo:'注音'}};
const dirtySet = new Set(DATA.steps_dirty || DATA.steps);
const cleanSet = new Set(DATA.steps_clean || DATA.steps);
const fontSel = document.getElementById('font');
const bucketSel = document.getElementById('bucket');
const layoutSel = document.getElementById('layout');
const cellSize = document.getElementById('cellSize');
DATA.fonts.forEach(f => {{ const o=document.createElement('option'); o.value=f; o.textContent=f; fontSel.appendChild(o); }});
[...new Set(DATA.items.map(i=>i.bucket))].forEach(b => {{ const o=document.createElement('option'); o.value=b; o.textContent=BNAME[b]||b; bucketSel.appendChild(o); }});

function defaultState(){{
  const key = KEY_STEPS.filter(s => DATA.steps.includes(s));
  return {{
    font: DATA.fonts[0],
    bucket: '',
    layout: 'pair',
    cell: 80,
    showContent: true, showGt: true, showF0d: true, showF0c100: true, showF0c95: false,
    steps: key.length ? key : DATA.steps.slice(0, Math.min(3, DATA.steps.length)),
    chars: DATA.chars.slice(),
  }};
}}
function loadState(){{
  try {{
    const raw = JSON.parse(localStorage.getItem(LS)||'{{}}');
    if ('showF0c' in raw && !('showF0c100' in raw)) {{
      raw.showF0c100 = !!raw.showF0c;
      raw.showF0c95 = false;
    }}
    const s = Object.assign(defaultState(), raw);
    if (!DATA.fonts.includes(s.font)) s.font = DATA.fonts[0];
    s.steps = (s.steps||[]).filter(x => DATA.steps.includes(x));
    if (!s.steps.length) s.steps = defaultState().steps;
    s.chars = (s.chars||[]).filter(c => DATA.chars.includes(c));
    if (!s.chars.length) s.chars = DATA.chars.slice();
    return s;
  }} catch(e) {{ return defaultState(); }}
}}
let ST = loadState();

function syncFromControls(){{
  ST.font = fontSel.value;
  ST.bucket = bucketSel.value || '';
  ST.layout = layoutSel.value;
  ST.cell = +cellSize.value;
  ST.showContent = document.getElementById('showContent').checked;
  ST.showGt = document.getElementById('showGt').checked;
  ST.showF0d = document.getElementById('showF0d').checked;
  ST.showF0c100 = document.getElementById('showF0c100').checked;
  ST.showF0c95 = document.getElementById('showF0c95').checked;
}}
function persistState(){{
  localStorage.setItem(LS, JSON.stringify(ST));
}}
function saveState(){{
  syncFromControls();
  persistState();
}}

function applyStateToControls(){{
  fontSel.value = ST.font;
  bucketSel.value = ST.bucket;
  layoutSel.value = ST.layout;
  cellSize.value = ST.cell;
  document.getElementById('cellSizeVal').textContent = ST.cell;
  document.documentElement.style.setProperty('--cell', ST.cell+'px');
  document.getElementById('showContent').checked = !!ST.showContent;
  document.getElementById('showGt').checked = !!ST.showGt;
  document.getElementById('showF0d').checked = !!ST.showF0d;
  document.getElementById('showF0c100').checked = ST.showF0c100 !== false;
  document.getElementById('showF0c95').checked = !!ST.showF0c95;
  const sc = document.getElementById('stepChips');
  sc.innerHTML = '';
  DATA.steps.forEach(s => {{
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'chip' + (ST.steps.includes(s) ? ' on' : '');
    const hasD = dirtySet.has(s), hasC = cleanSet.has(s);
    b.textContent = (s/1000)+'k' + (!hasD && hasC ? '·净' : hasD && !hasC ? '·脏' : '');
    b.onclick = () => {{
      if (ST.steps.includes(s)) ST.steps = ST.steps.filter(x=>x!==s);
      else ST.steps = DATA.steps.filter(x => ST.steps.includes(x) || x===s);
      render();
    }};
    sc.appendChild(b);
  }});
  const cc = document.getElementById('charChips');
  cc.classList.add('wrap');
  cc.innerHTML = '';
  DATA.chars.forEach(ch => {{
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'chip' + (ST.chars.includes(ch) ? ' on' : '');
    const probe = (DATA.effect_probe||[]).includes(ch);
    b.textContent = ch + (probe ? '★' : '');
    b.onclick = () => {{
      if (ST.chars.includes(ch)) ST.chars = ST.chars.filter(x=>x!==ch);
      else ST.chars = DATA.chars.filter(x => ST.chars.includes(x) || x===ch);
      render();
    }};
    cc.appendChild(b);
  }});
  document.getElementById('charDetails').querySelector('summary').textContent =
    '字符筛选 · 已选 '+ST.chars.length+'/'+DATA.chars.length+'（点击展开）';
}}

function renderRef8(font){{
  const refs = DATA.style_ref8[font] || [];
  document.getElementById('ref8lab').innerHTML =
    'Style×8 · Es+Δ 风格条件（'+DATA.ref8+'）· <span>'+font+'</span>';
  let h = '';
  for (const r of refs){{
    h += '<figure><img src="'+r.src+'" alt="'+r.ch+'" data-cap="Style '+r.ch+'" onerror="this.style.opacity=.2"/><figcaption>'+r.ch+'</figcaption></figure>';
  }}
  const box = document.getElementById('ref8figs');
  box.innerHTML = h;
  box.querySelectorAll('img').forEach(img => {{
    img.onclick = () => {{
      lbQueue = [{{src: img.src, cap: img.dataset.cap || img.alt}}];
      openLb(0);
    }};
  }});
}}

function buildCols(){{
  const layout = ST.layout;
  const steps = DATA.steps.filter(s => ST.steps.includes(s));
  const cols = [{{key:'ch', label:'字', sticky:true}}];
  if (ST.showContent) cols.push({{key:'content', label:'Content', sep:true}});
  if (ST.showGt) cols.push({{key:'gt', label:'GT'}});
  if (ST.showF0d) cols.push({{key:'f0d', label:'F0脏@100k', cls:'pair-d', sep:true}});
  if (ST.showF0c100) cols.push({{key:'f0c100', label:'F0净@100k', cls:'pair-c'}});
  if (ST.showF0c95) cols.push({{key:'f0c95', label:'F0净@95k', cls:'pair-c'}});
  for (const s of steps){{
    const hasD = dirtySet.has(s), hasC = cleanSet.has(s);
    const sk = (s/1000)+'k';
    let first = true;
    const push = (col) => {{ col.sep = first; first = false; cols.push(col); }};
    if (layout === 'pair'){{
      if (hasD) push({{key:'dirty_'+s, label:'脏@'+sk, cls:'pair-d'}});
      if (hasC) push({{key:'clean_'+s, label:'净@'+sk, cls:'pair-c'}});
    }} else if (layout === 'dirty'){{
      if (hasD) push({{key:'dirty_'+s, label:'脏@'+sk, cls:'pair-d'}});
    }} else if (layout === 'clean'){{
      if (hasC) push({{key:'clean_'+s, label:'净@'+sk, cls:'pair-c'}});
    }} else {{
      if (hasD) push({{key:'dirty_'+s, label:'脏@'+sk, cls:'pair-d'}});
      if (hasC) push({{key:'clean_'+s, label:'净@'+sk, cls:'pair-c'}});
    }}
  }}
  return cols;
}}

let lbQueue = [];
let lbIdx = 0;
function openLb(i){{
  if (!lbQueue.length) return;
  lbIdx = (i+lbQueue.length) % lbQueue.length;
  const q = lbQueue[lbIdx];
  document.getElementById('lbImg').src = q.src;
  document.getElementById('lbCap').textContent = q.cap;
  document.getElementById('lightbox').classList.add('on');
}}
function closeLb(){{ document.getElementById('lightbox').classList.remove('on'); }}
document.getElementById('lbClose').onclick = closeLb;
document.getElementById('lbPrev').onclick = () => openLb(lbIdx-1);
document.getElementById('lbNext').onclick = () => openLb(lbIdx+1);
document.getElementById('lightbox').onclick = (e) => {{ if (e.target.id==='lightbox') closeLb(); }};
document.addEventListener('keydown', (e) => {{
  if (!document.getElementById('lightbox').classList.contains('on')) {{
    if (e.key==='ArrowLeft') document.getElementById('fontPrev').click();
    if (e.key==='ArrowRight') document.getElementById('fontNext').click();
    return;
  }}
  if (e.key==='Escape') closeLb();
  if (e.key==='ArrowLeft') openLb(lbIdx-1);
  if (e.key==='ArrowRight') openLb(lbIdx+1);
}});

function render(){{
  // Apply ST → controls (chips etc). Do NOT syncFromControls here:
  // that would wipe ST updates from presets / shiftFont / chip toggles.
  applyStateToControls();
  persistState();
  const font = ST.font;
  renderRef8(font);
  const items = DATA.items.filter(it => {{
    if (it.font !== font) return false;
    if (!ST.chars.includes(it.char)) return false;
    if (bucketSel.value==='__effect__') return !!it.probe;
    if (bucketSel.value) return it.bucket===bucketSel.value;
    return true;
  }});
  const cols = buildCols();
  const bust = Date.now();
  lbQueue = [];
  let h = '<table class="g"><thead><tr>';
  for (const c of cols){{
    h += '<th class="'+(c.cls||'')+(c.sticky?' sticky':'')+(c.sep?' sep':'')+'">'+c.label+'</th>';
  }}
  h += '</tr></thead><tbody>';
  for (const it of items){{
    const mark = it.probe ? ' ★' : '';
    h += '<tr>';
    for (const c of cols){{
      if (c.key==='ch'){{
        h += '<td class="ch sticky">'+it.char+mark+'</td>';
        continue;
      }}
      let src = '', cap = it.font+' · '+it.char+' · '+c.label;
      if (c.key==='content') src = it.content;
      else if (c.key==='gt') src = it.gt;
      else if (c.key==='f0d') src = it.f0_dirty;
      else if (c.key==='f0c100') src = it.f0_clean_100k || it.f0_clean;
      else if (c.key==='f0c95') src = it.f0_clean_95k;
      else src = it.preds[c.key]||'';
      if (src) src = src + (src.includes('?') ? '&' : '?') + 't=' + bust;
      const qi = lbQueue.length;
      lbQueue.push({{src: src.split('?')[0], cap}});
      h += '<td class="'+(c.cls||'')+(c.sep?' sep':'')+'"><img src="'+src+'" alt="'+c.label+'" data-i="'+qi+'" loading="lazy" onerror="this.style.opacity=.2"/></td>';
    }}
    h += '</tr>';
  }}
  h += '</tbody></table>';
  const sheet = document.getElementById('sheet');
  const prevLeft = sheet.scrollLeft, prevTop = sheet.scrollTop;
  sheet.innerHTML = h;
  sheet.scrollLeft = prevLeft; sheet.scrollTop = prevTop;
  sheet.querySelectorAll('img[data-i]').forEach(img => {{
    img.onclick = () => openLb(+img.dataset.i);
  }});
}}

function shiftFont(d){{
  const i = DATA.fonts.indexOf(ST.font);
  ST.font = DATA.fonts[(i+d+DATA.fonts.length)%DATA.fonts.length];
  render();
}}
document.getElementById('fontPrev').onclick = () => shiftFont(-1);
document.getElementById('fontNext').onclick = () => shiftFont(1);
fontSel.onchange = () => {{ syncFromControls(); render(); }};
bucketSel.onchange = () => {{ syncFromControls(); render(); }};
layoutSel.onchange = () => {{ syncFromControls(); render(); }};
cellSize.oninput = () => {{
  document.getElementById('cellSizeVal').textContent = cellSize.value;
  document.documentElement.style.setProperty('--cell', cellSize.value+'px');
}};
cellSize.onchange = () => {{ syncFromControls(); render(); }};
['showContent','showGt','showF0d','showF0c100','showF0c95'].forEach(id => {{
  document.getElementById(id).onchange = () => {{ syncFromControls(); render(); }};
}});
document.getElementById('reloadImgs').onclick = () => {{ syncFromControls(); render(); }};
document.getElementById('stepsAll').onclick = () => {{ ST.steps = DATA.steps.slice(); render(); }};
document.getElementById('stepsNone').onclick = () => {{ ST.steps = []; render(); }};
document.getElementById('charsAll').onclick = () => {{ ST.chars = DATA.chars.slice(); render(); }};
document.getElementById('charsProbe').onclick = () => {{ ST.chars = (DATA.effect_probe||[]).slice(); document.getElementById('charDetails').open = true; render(); }};
document.getElementById('presetF0').onclick = () => {{
  ST.showContent = true; ST.showGt = true; ST.showF0d = true; ST.showF0c100 = true; ST.showF0c95 = true; ST.steps = []; render();
}};
document.getElementById('presetKey').onclick = () => {{
  ST.steps = KEY_STEPS.filter(s => DATA.steps.includes(s));
  ST.showContent = true; ST.showGt = true; ST.showF0d = true; ST.showF0c100 = true; ST.showF0c95 = false;
  ST.layout = 'pair';
  render();
}};
document.getElementById('presetAll').onclick = () => {{
  ST.steps = DATA.steps.slice();
  ST.showContent = true; ST.showGt = true; ST.showF0d = true; ST.showF0c100 = true; ST.showF0c95 = false;
  render();
}};
document.getElementById('toggleNote').onclick = () => {{
  document.getElementById('note').classList.toggle('on');
}};

render();
async function tick(){{
  try {{
    const s = await (await fetch('status.json?t='+Date.now(),{{cache:'no-store'}})).json();
    const ms = s.methods||{{}};
    const keys = Object.keys(ms).filter(k => k.includes('F2C') || k.includes('F2_clean') || k.startsWith('F2_timeline'));
    let t = '';
    for (const k of keys){{
      const v = ms[k]||{{}};
      if (v.phase !== 'running' && v.phase !== 'precompute') continue;
      const tot=v.total||0, d=(v.done||0)+(v.skipped||0);
      const pct = tot? Math.round(100*d/tot):0;
      t += k+' '+(v.phase||'')+' '+d+'/'+tot+' ('+pct+'%)';
      if (v.eta_s) t += ' ETA '+Math.round(v.eta_s/60)+'m';
      if (v.last) t += ' '+v.last;
      t += ' · ';
    }}
    document.getElementById('prog').textContent = t || '空闲 · 刷新更新图片 · ←/→ 换字体';
  }} catch(e) {{ document.getElementById('prog').textContent = String(e); }}
}}
tick(); setInterval(tick, 8000);
</script>
</body></html>
"""
    (OUT / "timeline_f2_clean.html").write_text(html, encoding="utf-8")
    print("wrote", OUT / "timeline_f2_clean.html", "items", len(items), "steps", steps)



def write_f2_timeline_html() -> None:
    steps = f2_timeline_steps()
    mids = [f2_mid(s) for s in steps]
    items = []
    for stem in fonts():
        for ch in TIMELINE_CHARS:
            preds = {
                f2_mid(s): f"preds/{f2_mid(s)}/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png" for s in steps
            }
            items.append(
                {
                    "font": stem,
                    "char": ch,
                    "cp": cp_of(ch),
                    "bucket": script_bucket(ch),
                    "content": f"refs/content/{cp_of(ch)}.png",
                    "style": f"refs/style/{stem}.png",
                    "gt": f"refs/gt/{stem}+{cp_of(ch)}.png",
                    "f0": f"preds/F0_100k/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "f3": f"preds/F3_80k/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png",
                    "preds": preds,
                }
            )
    payload = {
        "fonts": fonts(),
        "chars": TIMELINE_CHARS,
        "steps": steps,
        "mids": mids,
        "items": items,
        "note": "mid-train F2; 80k not included until DONE",
    }
    html = f"""<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<meta http-equiv="refresh" content="25"/>
<title>F2 训练过程 · test16</title>
<style>
:root{{--bg:#eef1f5;--card:#fff;--line:#d5dbe3;--muted:#5c6570;--ink:#1a1a1a;--accent:#1f4a6f}}
*{{box-sizing:border-box}} body{{margin:0;font:14px/1.45 system-ui,"Noto Sans SC",sans-serif;background:var(--bg);color:var(--ink)}}
header{{background:var(--card);border-bottom:1px solid var(--line);padding:14px 18px}}
h1{{margin:0;font-size:1.2rem}} .meta{{color:var(--muted);font-size:12px;margin-top:4px}}
main{{max-width:1500px;margin:16px auto;padding:0 14px 48px}}
.note{{background:#fff8e8;border:1px solid #e6d7a8;padding:8px 10px;margin:10px 0;font-size:12px}}
select{{padding:6px 8px;border:1px solid var(--line);background:#fff;margin-right:6px}}
.grid{{overflow-x:auto}}
table.g th,table.g td{{border:1px solid var(--line);padding:3px;text-align:center;vertical-align:bottom;font-size:11px;color:var(--muted)}}
table.g img{{width:72px;height:72px;image-rendering:pixelated;display:block;background:#fff}}
table.g td.ch{{font:700 15px/1.2 ui-serif,serif;color:var(--ink)}}
a{{color:var(--accent)}}
pre{{white-space:pre-wrap}}
</style></head><body>
<header>
  <h1>F2 从 5k 到 75k 的变化（中间结果）</h1>
  <div class="meta">协议同 F3 时间线：test16 × 16 跨语种字 · DPM++20 / CFG7.5 / seed 3407 · <a href="./">终点评测</a> · <a href="timeline.html">F3 过程</a></div>
</header>
<main>
<div class="note">左列为 GT / F0@100k / F3@80k 对照；其后每一列是 F2 checkpoint。条件是 <b>cache Δ only</b>（无 Support），与训练 <code>--no-support</code> 一致。75k 是当前续训前最后落盘点；80k 完成后可再补一列。像素观感诊断，不是风格终局。</div>
<section><pre id="prog" class="meta">读取进度…</pre></section>
<p>
  <label>字体 <select id="font"></select></label>
  <label>语种 <select id="bucket"><option value="">全部</option></select></label>
</p>
<div class="grid" id="sheet"></div>
</main>
<script>
const DATA = {json.dumps(payload, ensure_ascii=False)};
const BNAME = {{digit:'数字', latin_upper:'拉丁大写', latin_lower:'拉丁小写', latin_ext:'拉丁扩展', hiragana:'平假名', katakana:'片假名', bopomofo:'注音'}};
const fontSel = document.getElementById('font');
const bucketSel = document.getElementById('bucket');
DATA.fonts.forEach(f => {{ const o=document.createElement('option'); o.value=f; o.textContent=f; fontSel.appendChild(o); }});
[...new Set(DATA.items.map(i=>i.bucket))].forEach(b => {{ const o=document.createElement('option'); o.value=b; o.textContent=BNAME[b]||b; bucketSel.appendChild(o); }});
function render(){{
  const font=fontSel.value, bucket=bucketSel.value;
  const items=DATA.items.filter(it=>it.font===font && (!bucket || it.bucket===bucket));
  const heads=['字','Content','GT','F0@100k','F3@80k'].concat(DATA.steps.map(s=>'F2@'+(s/1000)+'k'));
  let h='<table class="g"><thead><tr>'+heads.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>';
  for (const it of items){{
    h += '<tr><td class="ch">'+it.char+'</td>';
    h += '<td><img src="'+it.content+'"/></td><td><img src="'+it.gt+'"/></td><td><img src="'+it.f0+'"/></td><td><img src="'+it.f3+'" onerror="this.style.opacity=.2"/></td>';
    for (const mid of DATA.mids){{
      h += '<td><img src="'+it.preds[mid]+'" onerror="this.style.opacity=.2"/></td>';
    }}
    h += '</tr>';
  }}
  document.getElementById('sheet').innerHTML = h+'</tbody></table>';
}}
fontSel.onchange=render; bucketSel.onchange=render; render();
async function tick(){{
  try {{
    const s = await (await fetch('status.json?t='+Date.now(),{{cache:'no-store'}})).json();
    const ms = s.methods||{{}};
    const keys = Object.keys(ms).filter(k => k==='F2_timeline' || k.startsWith('F2_timeline_'));
    let t = '';
    if (!keys.length) t = 'waiting…';
    for (const k of keys){{
      const v = ms[k]||{{}};
      const tot=v.total||0, d=(v.done||0)+(v.skipped||0);
      const pct = tot? Math.round(100*d/tot):0;
      t += k+' '+(v.phase||'')+' '+d+'/'+tot+' ('+pct+'%)';
      if (v.eta_s) t += ' ETA '+Math.round(v.eta_s/60)+'m';
      if (v.last) t += ' '+v.last;
      t += '\\n';
    }}
    document.getElementById('prog').textContent = t;
  }} catch(e) {{ document.getElementById('prog').textContent = String(e); }}
}}
tick(); setInterval(tick, 8000);
</script>
</body></html>
"""
    (OUT / "timeline_f2.html").write_text(html, encoding="utf-8")
    print("wrote", OUT / "timeline_f2.html", "items", len(items), "steps", steps)


def cmd_timeline(args: argparse.Namespace) -> None:
    refuse_busy_train_gpu()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "logs").mkdir(exist_ok=True)
    arm = getattr(args, "arm", "F3").upper()
    if arm in ("F2", "F2C"):
        if arm == "F2":
            write_f2_timeline_html()
        else:
            write_f2_clean_compare_html()
        if args.html_only:
            return
        stems = shard_list(fonts(), args.shard)
        if arm == "F2":
            run = F2_RUN
            es = ROOT / "artifacts/f0/es_spatial_f0"
            ec = ROOT / "artifacts/f0/ec_multiscale_f0"
            prefix = "F2_"
        else:
            run = ROOT / "runs/F2-CLEAN-V0913-A-S3407"
            es = ROOT / "artifacts/f0_clean_v0913/es_spatial"
            ec = ROOT / "artifacts/f0_clean_v0913/ec_multiscale"
            prefix = "F2C_"
            if not (es / "manifest.json").is_file() or not (ec / "manifest.json").is_file():
                raise SystemExit(f"missing clean Es/Ec under {es} / {ec}")
        steps = f2_timeline_steps(run)
        if getattr(args, "steps", None):
            want = {int(x) for x in args.steps.split(",") if x.strip()}
            steps = [s for s in steps if s in want]
        status_key = f"{'F2C' if arm == 'F2C' else 'F2'}_timeline_{args.shard.replace('/', 'of')}"
        char_s = getattr(args, "chars", None)
        if char_s:
            gen_chars = list(char_s)
        elif arm in ("F2C", "F2"):
            gen_chars = list(BOARD_CHARS)
        else:
            gen_chars = list(TIMELINE_CHARS)
        generate_f2_timeline(
            args.device,
            args.overwrite,
            stems=stems,
            steps=steps,
            status_key=status_key,
            run_dir=run,
            es_dir=es,
            ec_dir=ec,
            mid_prefix=prefix,
            chars=gen_chars,
        )
    else:
        write_timeline_html()
        if args.html_only:
            return
        generate_f3_timeline(args.device, args.overwrite)


def cmd_generate(args: argparse.Namespace) -> None:
    refuse_busy_train_gpu()
    configure_split(getattr(args, "split", "test"))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "logs").mkdir(exist_ok=True)
    stems = shard_list(fonts(), args.shard)
    protocol = {
        "split": EVAL_SPLIT,
        "n_fonts": len(fonts()),
        "fonts": fonts(),
        "chars": STRATIFIED,
        "chars_n": len(STRATIFIED),
        "seed": SEED,
        "sampler": "dpmsolver++ 20 CFG7.5 order2 multistep",
        "style": "ref8 first available, prefer 永; F2/F3 *_s1: Es from 永 only, Δ still ref8",
        "note": (
            "Same protocol as E1 formal stratified. Per-item set_seed(3407). "
            "style_oneshot splits Es k from Δ retrieve k. "
            f"This run is split={EVAL_SPLIT}."
        ),
        "methods": {
            k: {
                "label": v["label"],
                "kind": v["kind"],
                "ckpt": str(v["ckpt"]),
                "style_oneshot": bool(v.get("style_oneshot", False)),
            }
            for k, v in METHODS.items()
        },
    }
    (OUT / "PROTOCOL.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    update_status({"protocol": f"E1-stratified {EVAL_SPLIT}16×47 seed3407", "phase": "generate"})
    mid = args.method
    kind = METHODS[mid]["kind"]
    if kind == "f3":
        generate_f3(args.device, stems, args.overwrite, mid=mid)
    elif kind == "f2":
        generate_f2(args.device, stems, args.overwrite, mid=mid)
    elif kind == "f1":
        generate_f1(args.device, stems, args.overwrite, mid=mid)
    else:
        generate_image_method(mid, args.device, stems, args.overwrite)


def to_gray01(im: Image.Image) -> np.ndarray:
    return np.asarray(im.convert("L"), dtype=np.float32) / 255.0


def ssim(a: np.ndarray, b: np.ndarray) -> float:
    c1, c2 = 0.01**2, 0.03**2
    mu_a, mu_b = a.mean(), b.mean()
    sig_a, sig_b = a.var(), b.var()
    sig_ab = ((a - mu_a) * (b - mu_b)).mean()
    return float(((2 * mu_a * mu_b + c1) * (2 * sig_ab + c2)) / ((mu_a**2 + mu_b**2 + c1) * (sig_a + sig_b + c2)))


def ink_coverage(a: np.ndarray, thr: float = 0.92) -> float:
    return float((a < thr).mean())


def agg(rows: list[dict]) -> dict:
    if not rows:
        return {"n": 0}

    def mean(key: str):
        vals = [r[key] for r in rows if r.get(key) is not None]
        return float(sum(vals) / len(vals)) if vals else None

    return {
        "n": len(rows),
        "L1_mean": mean("L1"),
        "SSIM_mean": mean("SSIM"),
        "coverage_mean": mean("coverage"),
        "LPIPS_mean": mean("LPIPS"),
        "blank_rate": float(sum(1 for r in rows if (r.get("coverage") or 0) < 0.005) / len(rows)),
    }


def cmd_metrics(args: argparse.Namespace) -> None:
    refuse_busy_train_gpu()
    configure_split(getattr(args, "split", "test"))
    lpips_fn = None
    if args.lpips:
        import torch
        import lpips

        lpips_fn = lpips.LPIPS(net="alex").to(args.device).eval()
    want = [x.strip() for x in (getattr(args, "only", "") or "").split(",") if x.strip()]
    mids = want if want else list(METHODS)
    for mid in mids:
        if mid not in METHODS:
            raise SystemExit(f"unknown method {mid}")
    rows = []
    for mid in mids:
        for png in (OUT / "preds" / mid).rglob("*.png"):
            meta_p = png.with_suffix(".json")
            if not meta_p.is_file():
                continue
            meta = json.loads(meta_p.read_text(encoding="utf-8"))
            gtp = gt_path(meta["font"], meta["char"])
            if gtp is None:
                continue
            pred = Image.open(png).convert("RGB")
            gt = Image.open(gtp).convert("RGB")
            pa, ga = to_gray01(pred), to_gray01(gt)
            rec = {
                **meta,
                "L1": float(np.abs(pa - ga).mean()),
                "SSIM": ssim(pa, ga),
                "coverage": ink_coverage(pa),
                "LPIPS": None,
                "rel": str(png.relative_to(OUT)),
            }
            if lpips_fn is not None:
                import torch

                def to_n11(im: Image.Image):
                    arr = np.asarray(im.convert("RGB"), dtype=np.float32) / 255.0
                    t = torch.from_numpy(arr).permute(2, 0, 1)[None] * 2 - 1
                    return t.to(args.device)

                with torch.no_grad():
                    rec["LPIPS"] = float(lpips_fn(to_n11(pred), to_n11(gt)).item())
            rows.append(rec)
    by_m = defaultdict(list)
    for r in rows:
        by_m[r["method"]].append(r)
    new_methods = {}
    for mid, rs in by_m.items():
        by_b = defaultdict(list)
        for r in rs:
            by_b[r["bucket"]].append(r)
        new_methods[mid] = {
            "label": METHODS[mid]["label"],
            "overall": agg(rs),
            "by_bucket": {b: agg(by_b[b]) for b in BUCKET_ORDER if b in by_b},
        }
    summary_p = OUT / "metrics_summary.json"
    items_p = OUT / "metrics_items.json"
    if want and summary_p.is_file():
        report = json.loads(summary_p.read_text(encoding="utf-8"))
        report.setdefault("methods", {})
        report["methods"].update(new_methods)
        report["computed_at"] = utc_now()
        report["caveat"] = (
            "L1/SSIM/LPIPS vs GT are diagnostics, not the paper style claim. "
            "Mode D (*_s1) is style-k ablation with Δ still ref8."
        )
        if items_p.is_file():
            old_rows = json.loads(items_p.read_text(encoding="utf-8"))
            drop = set(want)
            rows = [r for r in old_rows if r.get("method") not in drop] + rows
        report["n_total"] = len(rows)
    else:
        report = {
            "computed_at": utc_now(),
            "n_total": len(rows),
            "caveat": "L1/SSIM/LPIPS vs GT are diagnostics, not the paper style claim. E12 still gated.",
            "methods": new_methods,
        }
    (OUT / "metrics_summary.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (OUT / "metrics_items.json").write_text(json.dumps(rows, ensure_ascii=False) + "\n", encoding="utf-8")
    update_status({"phase": "metrics_done", "n_metric_rows": len(rows), "scored": mids})
    print(json.dumps({m: report["methods"][m]["overall"] for m in report["methods"]}, indent=2))


def copy_refs() -> None:
    ref = OUT / "refs"
    (ref / "content").mkdir(parents=True, exist_ok=True)
    (ref / "gt").mkdir(parents=True, exist_ok=True)
    (ref / "style").mkdir(parents=True, exist_ok=True)
    for ch in STRATIFIED:
        Image.open(content_path(ch)).convert("RGB").resize((96, 96)).save(ref / "content" / f"{cp_of(ch)}.png")
    for stem in fonts():
        Image.open(pick_style_path(stem)).convert("RGB").resize((96, 96)).save(ref / "style" / f"{stem}.png")
        for ch in STRATIFIED:
            g = gt_path(stem, ch)
            dst = ref / "gt" / f"{stem}+{cp_of(ch)}.png"
            if g:
                Image.open(g).convert("RGB").resize((96, 96)).save(dst)


VAL_BOARD_ARMS = [
    {"id": "F2", "label": "F2@40k", "s8": "F2_40000", "s1": "F2_40000_k1", "tone": "f2"},
    {"id": "F2P", "label": "F2-P@40k", "s8": "F2P_40000", "s1": "F2P_40000_k1", "tone": "p"},
    {"id": "F2RL", "label": "F2-RL128@40k", "s8": "F2RL_40000", "s1": "F2RL_40000_k1", "tone": "rl"},
    {"id": "F2PRL", "label": "F2-PRL@40k", "s8": "F2PRL_40000", "s1": "F2PRL_40000_k1", "tone": "prl"},
    {"id": "F280", "label": "F2@80k", "s8": "F2_80000", "s1": "F2_80000_k1", "tone": "long"},
]
VAL_BOARD_LEAD_FONTS = [
    "FZCaoQBLSJW",
    "FZMiFXSJW",
    "FZBangSKKXJW",
    "FZQingYSJW-T",
    "FZSongKBXKJW-EB",
    "FZHengFSJW-T",
]
VAL_BOARD_FOCUS_CHARS = list("AQaRgあのIl1")


def write_val_board() -> None:
    """Paired 8-shot / 1-shot board. Does not touch the test16 glyph board."""
    metrics = {}
    mp = OUT / "metrics_summary.json"
    if mp.is_file():
        raw = json.loads(mp.read_text(encoding="utf-8"))
        metrics = raw.get("methods", {})
    stems = fonts()
    lead = [s for s in VAL_BOARD_LEAD_FONTS if s in stems]
    ordered = lead + [s for s in stems if s not in lead]
    payload = {
        "generated_at": utc_now(),
        "split": EVAL_SPLIT,
        "seed": SEED,
        "n_fonts": len(ordered),
        "n_chars": len(STRATIFIED),
        "fonts": ordered,
        "lead": lead,
        "focus_chars": VAL_BOARD_FOCUS_CHARS,
        "chars": [{"ch": ch, "cp": cp_of(ch), "bucket": script_bucket(ch)} for ch in STRATIFIED],
        "buckets": BUCKET_ORDER,
        "arms": VAL_BOARD_ARMS,
        "metrics": {
            mid: (metrics.get(mid) or {}).get("overall") or {}
            for arm in VAL_BOARD_ARMS
            for mid in (arm["s8"], arm["s1"])
        },
        "paths": {
            "pred": f"preds/{{mid}}/{EVAL_SPLIT}/{{stem}}/{EVAL_SPLIT}__{{stem}}__{{cp}}__s{SEED}.png",
            "gt": "refs/gt/{stem}+{cp}.png",
            "style": "refs/style/{stem}.png",
            "content": "refs/content/{cp}.png",
        },
    }
    (OUT / "board.json").write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    data_js = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    html = VAL_BOARD_HTML.replace("__DATA__", data_js)
    (OUT / "index.html").write_text(html, encoding="utf-8")


VAL_BOARD_HTML = r"""<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/>
<title>val16 · F2 1-shot vs 8-shot</title>
<style>
:root {
  --bg:#14120f; --card:#1c1914; --line:#3a342c; --fg:#e4dcc8;
  --muted:#8d8473; --acc:#b7c98a; --warn:#c8a24b; --head:#221e18;
  --gt:#c8a24b; --f2:#6aa8a0; --p:#d4a574; --rl:#9b8fd4; --long:#7aa0c8;
}
* { box-sizing:border-box; }
html, body { height:100%; }
body {
  margin:0; display:flex; flex-direction:column; overflow:hidden;
  font-family:ui-sans-serif,system-ui,sans-serif; background:var(--bg); color:var(--fg);
}
header { flex:0 0 auto; background:var(--card); border-bottom:1px solid var(--line); padding:10px 16px 8px; }
h1 { font-size:1.05rem; margin:0 0 4px; font-weight:650; }
.meta { color:var(--muted); font-size:12px; max-width:130ch; line-height:1.45; }
.bar { display:flex; flex-wrap:wrap; gap:8px 14px; align-items:center; margin-top:8px; font-size:13px; }
.bar label { cursor:pointer; }
select, button, input[type=range] {
  background:var(--head); color:var(--fg); border:1px solid var(--line); padding:4px 8px; font:inherit;
}
button:hover, label.chip:hover { border-color:var(--acc); color:var(--acc); }
label.chip {
  border:1px solid var(--line); padding:2px 8px; border-radius:999px; background:var(--head);
}
label.chip input { accent-color:var(--acc); }
main { flex:1; min-height:0; display:flex; flex-direction:column; padding:8px 16px 10px; }
.metrics { flex:0 0 auto; overflow:auto; margin-bottom:8px; }
.metrics table { border-collapse:collapse; font-size:12px; }
.metrics th, .metrics td { border:1px solid var(--line); padding:4px 8px; text-align:right; }
.metrics th:first-child, .metrics td:first-child { text-align:left; white-space:nowrap; }
.metrics .pair8 { color:#b7e4de; }
.metrics .pair1 { color:#f0d078; }
.scroll { flex:1; min-height:0; overflow:auto; border:1px solid var(--line); background:#17140f; }
table.grid { border-collapse:separate; border-spacing:0; font-size:11px; }
.grid th, .grid td {
  border-right:1px solid var(--line); border-bottom:1px solid var(--line);
  padding:3px 4px; text-align:center; vertical-align:middle;
}
.grid thead th { position:sticky; top:0; z-index:6; background:var(--head); white-space:nowrap; padding:5px 4px; }
.grid thead tr.sub th { top:28px; font-size:10px; letter-spacing:.04em; }
.grid th.stub, .grid td.stub {
  position:sticky; left:0; z-index:8; background:var(--card);
  font-weight:700; min-width:7.5em; text-align:left; padding-left:8px;
  box-shadow:1px 0 0 var(--line);
}
.grid thead th.stub { z-index:10; }
.grid td.chr { font-size:18px; font-weight:700; min-width:2.2em; text-align:center; }
img.g { width:var(--gs,64px); height:var(--gs,64px); image-rendering:pixelated; background:#fff; display:block; cursor:zoom-in; }
.tone-gt { background:#2f2614; }
thead th.tone-gt { color:#f0d078; box-shadow:inset 0 -3px 0 var(--gt); }
.tone-f2 { background:#141c1b; }
thead th.tone-f2 { color:#b7e4de; box-shadow:inset 0 -3px 0 var(--f2); }
.tone-p { background:#241c14; }
thead th.tone-p { color:#f0d0a8; box-shadow:inset 0 -3px 0 var(--p); }
.tone-rl { background:#1b1724; }
thead th.tone-rl { color:#d4c8ff; box-shadow:inset 0 -3px 0 var(--rl); }
.tone-long { background:#14202a; }
thead th.tone-long { color:#b7d4ee; box-shadow:inset 0 -3px 0 var(--long); }
.shot8 { color:#b7e4de; }
.shot1 { color:#f0d078; }
td.hl { outline:2px solid #f0d078; outline-offset:-2px; }
.miss { color:#555; }
#zoom {
  display:none; position:fixed; inset:0; z-index:40; background:rgba(0,0,0,.78);
  align-items:center; justify-content:center; padding:24px;
}
#zoom.on { display:flex; }
#zoom .box { background:var(--card); border:1px solid var(--line); padding:12px 16px; max-width:96vw; }
#zoom .row { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; }
#zoom figure { margin:0; text-align:center; }
#zoom img { width:160px; height:160px; image-rendering:pixelated; background:#fff; }
#zoom figcaption { color:var(--muted); font-size:12px; margin-top:4px; }
</style></head><body>
<header>
  <h1>val16 · F2 1-shot vs 8-shot</h1>
  <p class="meta">非正式主表。同一行里 8-shot 和 1-shot 紧挨着。8-shot：Es+Δ = 永和书风骨韵天地。1-shot：Es+Δ 都只用「永」。DPM++20 CFG7.5 seed 3407。点图放大。</p>
  <div class="bar">
    <label>视图
      <select id="view">
        <option value="char">固定字体 · 逐字</option>
        <option value="font">固定字 · 逐字体</option>
      </select>
    </label>
    <label>字体 <select id="font"></select></label>
    <label>字 <select id="char"></select></label>
    <label>语种 <select id="bucket"><option value="">全部</option></select></label>
    <label><input type="checkbox" id="focus"/> 论文探针字</label>
    <span id="armToggles"></span>
    <label>大小 <input id="size" type="range" min="48" max="96" value="64"/></label>
  </div>
</header>
<main>
  <div class="metrics" id="metrics"></div>
  <div class="scroll"><table class="grid" id="grid"></table></div>
</main>
<div id="zoom"><div class="box"><div id="zoomCap" class="meta"></div><div class="row" id="zoomRow"></div></div></div>
<script>
const DATA = __DATA__;
const $ = id => document.getElementById(id);
const tone = {gt:"tone-gt", f2:"tone-f2", p:"tone-p", rl:"tone-rl", long:"tone-long"};
function fmt(x, n=4){ return (x==null || x==="") ? "—" : Number(x).toFixed(n); }
function path(tpl, o){
  return tpl.replaceAll("{mid}", o.mid||"").replaceAll("{stem}", o.stem||"").replaceAll("{cp}", o.cp||"");
}
function img(src, cls){
  return `<img class="g ${cls||""}" src="${src}" width="64" height="64" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'miss',textContent:'·'}))"/>`;
}
function selectedArms(){
  return DATA.arms.filter(a => $("arm_"+a.id).checked);
}
function fillSelects(){
  $("font").innerHTML = DATA.fonts.map(f => `<option value="${f}">${f}${DATA.lead.includes(f)?" · 笔意":""}</option>`).join("");
  $("font").value = DATA.lead[0] || DATA.fonts[0];
  $("char").innerHTML = DATA.chars.map(c => `<option value="${c.ch}">${c.ch} · ${c.bucket}</option>`).join("");
  $("char").value = DATA.focus_chars[0] || DATA.chars[0].ch;
  $("bucket").innerHTML = `<option value="">全部</option>` + DATA.buckets.map(b => `<option value="${b}">${b}</option>`).join("");
  $("armToggles").innerHTML = DATA.arms.map(a =>
    `<label class="chip"><input type="checkbox" id="arm_${a.id}" checked/> ${a.label}</label>`
  ).join("");
}
function charsFiltered(){
  const b = $("bucket").value;
  const focus = $("focus").checked;
  return DATA.chars.filter(c => (!b || c.bucket===b) && (!focus || DATA.focus_chars.includes(c.ch)));
}
function renderMetrics(){
  const head = `<tr><th>方法</th><th class="pair8">8 L1</th><th class="pair1">1 L1</th><th class="pair8">8 SSIM</th><th class="pair1">1 SSIM</th><th class="pair8">8 LPIPS</th><th class="pair1">1 LPIPS</th></tr>`;
  const rows = DATA.arms.map(a => {
    const m8 = DATA.metrics[a.s8]||{}; const m1 = DATA.metrics[a.s1]||{};
    return `<tr><td>${a.label}</td>
      <td class="pair8">${fmt(m8.L1_mean)}</td><td class="pair1">${fmt(m1.L1_mean)}</td>
      <td class="pair8">${fmt(m8.SSIM_mean)}</td><td class="pair1">${fmt(m1.SSIM_mean)}</td>
      <td class="pair8">${fmt(m8.LPIPS_mean)}</td><td class="pair1">${fmt(m1.LPIPS_mean)}</td></tr>`;
  }).join("");
  $("metrics").innerHTML = `<table><thead>${head}</thead><tbody>${rows}</tbody></table>`;
}
function cell(mid, stem, ch, cp, shotCls){
  const src = path(DATA.paths.pred, {mid, stem, cp});
  return `<td class="${shotCls}" data-mid="${mid}" data-stem="${stem}" data-ch="${ch}" data-cp="${cp}">${img(src)}</td>`;
}
function render(){
  const arms = selectedArms();
  const view = $("view").value;
  const size = $("size").value;
  document.documentElement.style.setProperty("--gs", size+"px");
  let top = `<tr><th class="stub" rowspan="2">${view==="char"?"字":"字体"}</th>
    <th class="tone-gt" rowspan="2">Content</th><th class="tone-gt" rowspan="2">Style</th><th class="tone-gt" rowspan="2">GT</th>`;
  arms.forEach(a => { top += `<th class="${tone[a.tone]}" colspan="2">${a.label}</th>`; });
  top += `</tr><tr class="sub">`;
  arms.forEach(a => { top += `<th class="${tone[a.tone]} shot8">8</th><th class="${tone[a.tone]} shot1">1</th>`; });
  top += `</tr>`;
  let body = "";
  if (view === "char") {
    const stem = $("font").value;
    charsFiltered().forEach(c => {
      body += `<tr><td class="stub chr">${c.ch}<div class="meta">${c.bucket}</div></td>
        <td class="tone-gt">${img(path(DATA.paths.content,{cp:c.cp}))}</td>
        <td class="tone-gt">${img(path(DATA.paths.style,{stem}))}</td>
        <td class="tone-gt">${img(path(DATA.paths.gt,{stem, cp:c.cp}))}</td>`;
      arms.forEach(a => {
        body += cell(a.s8, stem, c.ch, c.cp, tone[a.tone]+" shot8");
        body += cell(a.s1, stem, c.ch, c.cp, tone[a.tone]+" shot1");
      });
      body += `</tr>`;
    });
  } else {
    const ch = $("char").value;
    const rec = DATA.chars.find(c => c.ch===ch) || DATA.chars[0];
    DATA.fonts.forEach(stem => {
      body += `<tr><td class="stub"><code>${stem}</code></td>
        <td class="tone-gt">${img(path(DATA.paths.content,{cp:rec.cp}))}</td>
        <td class="tone-gt">${img(path(DATA.paths.style,{stem}))}</td>
        <td class="tone-gt">${img(path(DATA.paths.gt,{stem, cp:rec.cp}))}</td>`;
      arms.forEach(a => {
        body += cell(a.s8, stem, rec.ch, rec.cp, tone[a.tone]+" shot8");
        body += cell(a.s1, stem, rec.ch, rec.cp, tone[a.tone]+" shot1");
      });
      body += `</tr>`;
    });
  }
  $("grid").innerHTML = `<thead>${top}</thead><tbody>${body}</tbody>`;
}
function zoomFrom(td){
  const stem = td.dataset.stem, ch = td.dataset.ch, cp = td.dataset.cp;
  const rec = DATA.chars.find(c => c.ch===ch);
  $("zoomCap").textContent = `${stem} · ${ch} · ${rec?rec.bucket:""}`;
  let html = `<figure><figcaption>GT</figcaption>${img(path(DATA.paths.gt,{stem,cp}))}</figure>`;
  selectedArms().forEach(a => {
    html += `<figure><figcaption>${a.label} 8</figcaption>${img(path(DATA.paths.pred,{mid:a.s8,stem,cp}))}</figure>`;
    html += `<figure><figcaption>${a.label} 1</figcaption>${img(path(DATA.paths.pred,{mid:a.s1,stem,cp}))}</figure>`;
  });
  $("zoomRow").innerHTML = html;
  $("zoom").classList.add("on");
}
function bind(){
  ["view","font","char","bucket","focus","size"].forEach(id => $(id).addEventListener("change", render));
  $("size").addEventListener("input", render);
  DATA.arms.forEach(a => $("arm_"+a.id).addEventListener("change", render));
  $("view").addEventListener("change", () => {
    $("font").disabled = $("view").value!=="char";
    $("char").disabled = $("view").value!=="font";
  });
  $("grid").addEventListener("click", e => {
    const td = e.target.closest("td[data-mid]");
    if (td) zoomFrom(td);
  });
  $("zoom").addEventListener("click", () => $("zoom").classList.remove("on"));
  document.addEventListener("keydown", e => {
    if (e.key==="Escape") $("zoom").classList.remove("on");
  });
}
fillSelects();
renderMetrics();
$("font").disabled = false;
$("char").disabled = true;
bind();
render();
</script>
</body></html>
"""


def cmd_gallery(_args: argparse.Namespace) -> None:
    """Refresh browse_index refs; prefer fair-axes HTML rebuild (keeps E1 if present)."""
    configure_split(getattr(_args, "split", "test"))
    if EVAL_SPLIT != "test":
        copy_refs()
        write_val_board()
        update_status({"phase": "gallery_done", "ui": "val16_f2", "n_fonts": len(fonts())})
        print("wrote", OUT / "index.html")
        return
    copy_refs()
    # Prefer dedicated rebuild: preserves E1 columns + Mode A/B/C UI.
    rebuild = ROOT / "scripts/rebuild_glyph_board_fair_axes.py"
    if rebuild.is_file() and (OUT / "browse_index.json").is_file():
        import runpy

        runpy.run_path(str(rebuild), run_name="__main__")
        update_status({"phase": "gallery_done", "ui": "fair_axes_v1"})
        return
    metrics = {}
    mp = OUT / "metrics_summary.json"
    if mp.is_file():
        metrics = json.loads(mp.read_text(encoding="utf-8"))
    items = []
    for stem in fonts():
        for ch in STRATIFIED:
            items.append(
                {
                    "font": stem,
                    "char": ch,
                    "cp": cp_of(ch),
                    "bucket": script_bucket(ch),
                    "content": f"refs/content/{cp_of(ch)}.png",
                    "style": f"refs/style/{stem}.png",
                    "gt": f"refs/gt/{stem}+{cp_of(ch)}.png",
                    "preds": {
                        mid: f"preds/{mid}/test/{stem}/test__{stem}__{cp_of(ch)}__s{SEED}.png" for mid in METHODS
                    },
                }
            )
    payload = {
        "generated_at": utc_now(),
        "fonts": fonts(),
        "chars": STRATIFIED,
        "buckets": BUCKET_ORDER,
        "methods": [{"id": k, "label": v["label"]} for k, v in METHODS.items()],
        "metrics": metrics,
        "items": items,
        "n": len(items),
    }
    (OUT / "browse_index.json").write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    write_html(payload)
    update_status({"phase": "gallery_done", "n_items": len(items)})
    print("wrote", OUT / "index.html", "items", len(items))


def _fmt(x, n=4) -> str:
    return f"{x:.{n}f}" if isinstance(x, (int, float)) else "—"


def write_html(payload: dict) -> None:
    """Delegate to fair-axes board builder (Mode A/B/C). Keeps payload on disk first."""
    (OUT / "browse_index.json").write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    rebuild = ROOT / "scripts/rebuild_glyph_board_fair_axes.py"
    if rebuild.is_file():
        import runpy

        runpy.run_path(str(rebuild), run_name="__main__")
        return
    # Fallback: minimal stub if rebuild script missing
    (OUT / "index.html").write_text(
        "<!doctype html><meta charset=utf-8><title>f03 board</title>"
        "<p>Missing scripts/rebuild_glyph_board_fair_axes.py — cannot render fair-axis board.</p>\n",
        encoding="utf-8",
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("generate")
    g.add_argument("--method", required=True, choices=list(METHODS))
    g.add_argument("--device", default="cuda:0")
    g.add_argument("--shard", default="0/1")
    g.add_argument("--overwrite", action="store_true")
    g.add_argument("--split", choices=["test", "val"], default="test")
    g.set_defaults(func=cmd_generate)
    m = sub.add_parser("metrics")
    m.add_argument("--device", default="cuda:0")
    m.add_argument("--lpips", action="store_true")
    m.add_argument("--only", default="", help="comma-separated method ids; merge into existing metrics_summary")
    m.add_argument("--split", choices=["test", "val"], default="test")
    m.set_defaults(func=cmd_metrics)
    gal = sub.add_parser("gallery")
    gal.add_argument("--split", choices=["test", "val"], default="test")
    gal.set_defaults(func=cmd_gallery)
    p = sub.add_parser("progress-page")
    p.set_defaults(func=cmd_gallery)
    t = sub.add_parser("timeline")
    t.add_argument("--arm", choices=["F2", "F3", "f2", "f3", "F2C", "f2c"], default="F3")
    t.add_argument("--device", default="cuda:0")
    t.add_argument("--shard", default="0/1", help="font shard i/n; result-safe with per-item seed")
    t.add_argument("--steps", default="", help="optional comma steps e.g. 5000,10000")
    t.add_argument(
        "--chars",
        default="",
        help="optional literal chars to sample; default TIMELINE(+i/j for F2C)",
    )
    t.add_argument("--overwrite", action="store_true")
    t.add_argument("--html-only", action="store_true")
    t.set_defaults(func=cmd_timeline)
    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
